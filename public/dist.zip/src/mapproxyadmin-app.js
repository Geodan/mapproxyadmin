define(["exports"],function(_exports){"use strict";Object.defineProperty(_exports,"__esModule",{value:!0});_exports.insertNodeIntoTemplate=insertNodeIntoTemplate;_exports.pathJoin=pathJoin;_exports.property$1=_exports.property=property;_exports.removeNodesFromTemplate=removeNodesFromTemplate;_exports.templateFactory$1=_exports.templateFactory=templateFactory;_exports.reparentNodes=_exports.render$1=_exports.render$2=_exports.render=_exports.removeNodes$1=_exports.removeNodes=_exports.queryAll$1=_exports.queryAll=_exports.query$1=_exports.query=_exports.parts$1=_exports.parts=_exports.nothing$1=_exports.nothing=_exports.notEqual$1=_exports.notEqual=_exports.nodeMarker=_exports.noChange$1=_exports.noChange=_exports.markerRegex=_exports.marker=_exports.lastAttributeNameRegex=_exports.isTemplatePartActive$1=_exports.isTemplatePartActive=_exports.isPrimitive$1=_exports.isPrimitive=_exports.isDirective$1=_exports.isDirective=_exports.isCEPolyfill=_exports.html$2=_exports.html$1=_exports.html=_exports.eventOptions$1=_exports.eventOptions=_exports.directive$1=_exports.directive=_exports.defaultTemplateProcessor$1=_exports.defaultTemplateProcessor=_exports.defaultConverter$1=_exports.defaultConverter=_exports.customElement$1=_exports.customElement=_exports.css$1=_exports.css=_exports.createMarker$1=_exports.createMarker=_exports.boundAttributeSuffix=_exports.UpdatingElement$1=_exports.UpdatingElement=_exports.TemplateResult$3=_exports.TemplateResult$2=_exports.TemplateResult$1=_exports.TemplateResult=_exports.TemplateInstance$1=_exports.TemplateInstance=_exports.Template$1=_exports.Template=_exports.SVGTemplateResult$2=_exports.SVGTemplateResult$1=_exports.SVGTemplateResult=_exports.PropertyPart$1=_exports.PropertyPart=_exports.PropertyCommitter$1=_exports.PropertyCommitter=_exports.NodePart$1=_exports.NodePart=_exports.MapproxyList=_exports.LitElement=_exports.EventPart$1=_exports.EventPart=_exports.DefaultTemplateProcessor$1=_exports.DefaultTemplateProcessor=_exports.CSSResult$1=_exports.CSSResult=_exports.BooleanAttributePart$1=_exports.BooleanAttributePart=_exports.AttributePart$1=_exports.AttributePart=_exports.AttributeCommitter$1=_exports.AttributeCommitter=_exports.$util=_exports.$updatingElement=_exports.$unsafeHtml=_exports.$templateResult=_exports.$templateInstance=_exports.$templateFactory=_exports.$template=_exports.$shadyRender=_exports.$render=_exports.$parts=_exports.$part=_exports.$modifyTemplate=_exports.$mapproxyList=_exports.$litHtml=_exports.$litElement=_exports.$dom=_exports.$directive=_exports.$defaultTemplateProcessor=_exports.$decorators=_exports.$cssTag=void 0;_exports.unsafeHTML=_exports.unsafeCSS$1=_exports.unsafeCSS=_exports.templateCaches$1=_exports.templateCaches=_exports.svg$2=_exports.svg$1=_exports.svg=_exports.supportsAdoptingStyleSheets$1=_exports.supportsAdoptingStyleSheets=_exports.reparentNodes$1=void 0;function _templateObject51_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n        <mapproxy-new class=\"config newconfig\" .config=\"","\" .list="," @localConfigUpdate=\"","\" @itemadd=\"","\"></mapproxy-new>\n        <mapproxy-list class=\"config listconfig\" .config=\"","\" .list="," .localConfig=\"","\" @itemdelete=\"","\"></mapproxy-list>\n        "]);_templateObject51_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject51_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject50_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["",": ",""]);_templateObject50_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject50_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject49_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["client_config.json: ",""]);_templateObject49_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject49_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject48_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            .config {\n                border: 1px solid gray;\n                border-radius: 5px;\n                margin-bottom: 15px;\n                padding: 5px;\n            }\n            .newconfig {\n                background: lightyellow;\n            }\n            .listconfig {\n                background: #e6ffe6;\n            }\n        "]);_templateObject48_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject48_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject47_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <mapproxy-config .config=\"","\"></mapproxy-config>\n            <mapproxy-getcaps .list=\"","\"></mapproxy-getcaps>\n            "]);_templateObject47_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject47_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject46_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject46_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject46_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject45_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <mp-accordion @click=\"","\">New mapproxy config...</mp-accordion>\n            <div class=\"panel\">\n            ","\n            </div>\n            "]);_templateObject45_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject45_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject44_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;\n            }\n            .panel {\n                margin-left: 20px;\n            }\n        "]);_templateObject44_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject44_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject43_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <mapproxy-item .item=\"","\" .localConfig=\"","\"></mapproxy-item>"]);_templateObject43_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject43_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject42_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["",""]);_templateObject42_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject42_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject41_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject41_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject41_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject40_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<mp-accordion @click=\"","\">List mapproxy configs...</mp-accordion>\n        <div class=\"panel\">\n        ","\n        </div>"]);_templateObject40_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject40_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject39_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {display: block;}\n            .panel {margin-left: 20px;}\n        "]);_templateObject39_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject39_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject38_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<br>",""]);_templateObject38_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject38_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject37_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["","<br>"]);_templateObject37_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject37_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject36_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["function"]);_templateObject36_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject36_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject35_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["","<br>"]);_templateObject35_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject35_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject34_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<b>","</b>: "]);_templateObject34_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject34_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject33_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<li><mapproxy-layer .itemname=\"","\" .item=\"","\" .layer=\"","\" .localConfig=\"","\"></mapproxy-layer></li>"]);_templateObject33_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject33_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject32_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""," "]);_templateObject32_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject32_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject31_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <a href=\"","/","/demo\" target=\"mapproxypreview\">preview</a> ","\n            <button @click=\"","\">delete</button><br>\n            <b>services</b>: ","<br>\n            <b>metadata</b>:<br>","\n            <b>layers</b>:\n            <ul>\n            ","\n            </ul>\n            "]);_templateObject31_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject31_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject30_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject30_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject30_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject29_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject29_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject29_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject28_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n                <mp-accordion @click=\"","\" .open=\"","\">","</mp-accordion>\n                <div class=\"panel\">\n                ","\n                </div>\n                    "]);_templateObject28_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject28_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject27_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;\n            }\n            .panel {\n                margin-left: 20px;\n            }\n        "]);_templateObject27_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject27_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject26_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            ","\n        "]);_templateObject26_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject26_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject25_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            bbox: ",", srs: ","\n        "]);_templateObject25_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject25_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject24_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["max_res: ",""]);_templateObject24_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject24_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject23_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["min_res: ",""]);_templateObject23_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject23_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject22_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            ","\n            ","\n        "]);_templateObject22_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject22_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject21_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            ","\n            <a href=\"","/","/demo/?srs=EPSG%3A3857&format=image%2Fpng&wms_layer=","\" target=\"mapproxypreview\">preview</a>\n            <button @click=\"","\">clear cache</button>\n            ","\n            ","\n            ","\n            "]);_templateObject21_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject21_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject20_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;\n            }\n        "]);_templateObject20_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject20_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject19_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["","","<br>",""]);_templateObject19_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject19_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject18_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["noname"]);_templateObject18_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject18_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject17_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["",""]);_templateObject17_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject17_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject16_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<input id=\"","\" type=\"checkbox\" ?checked=\"","\" @change=\"","\"><label for=\"","\">","</label>, ","",""]);_templateObject16_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject16_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject15_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <div>\n            <b>Title</b>: ","<br>\n            <b>Abstract</b>: ","<br>\n            <b>Access constraints</b>: ","<br>\n            <b>Fees</b>: ","<br>\n            <b>Contact information</b><br>\n            <b>Primary contact</b>: ","<br>\n            <b>Primary contact organization</b>: ","<br>\n            <b>Contact voice telephone</b>: ","<br>\n            <b>Contact mail</b>: ","<br>\n            <b>Layers</b><br>\n            <input type=\"checkbox\" id=\"allchecks\" @click=\"","\" checked><Label for=\"allchecks\">(un-)select all layers</Label><br>\n            ","\n            <input type=\"text\" @input=\"","\" id=\"configname\" size=\"20\" value=\"\" placeholder=\"mapproxy_config_name\"> <button ?disabled=\"","\" @click=\"","\">Create</button> ","\n            </div>\n        "]);_templateObject15_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject15_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject14_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject14_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject14_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject13_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject13_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject13_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject12_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<div class=\"error\">","</div>"]);_templateObject12_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject12_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject11_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject11_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject11_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject10_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <input type=\"text\" autocomplete=\"url\" id=\"wmscapabilitiesurl\" name=\"wmscapabilitiesurl\" size=\"128\" value=\"","\" placeholder=\"HTTP(s) address of WMS service\">\n            <button @click=\"","\">Get</button> ","\n        "]);_templateObject10_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject10_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject9_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject9_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject9_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject8_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <mp-accordion @click=\"","\">Get layers from WMS capabilities</mp-accordion>\n            <div class=\"panel\">\n            ","\n            ","\n            ","\n            </div>\n            "]);_templateObject8_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject8_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject7_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;                \n            }\n            .panel {\n                margin-left: 20px;\n            }\n            .error {\n                color: red;\n            }\n        "]);_templateObject7_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject7_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject6_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <label for=\"mapproxydir\">Mapproxy root directory:</label>\n            <input type=\"text\" id=\"mapproxydir\" name=\"mapproxydir\" size=\"65\" value=\"","\"><br>\n            <label for=\"online_resource\">Online resource</label>\n            <input type=\"text\" id=\"online_resource\" name=\"online_resource\" size=\"65\" value=\"","\"><br>\n            <label for=\"access_constraints\">Access constraints</label>\n            <input type=\"text\" id=\"access_constraints\" name=\"access_constraints\" size=\"65\" value=\"","\"><br>\n            <label for=\"fees\">Fees</label>\n            <input type=\"text\" id=\"fees\" name=\"fees\" size=\"65\"  value=\"","\"><br>\n            <b>Contact</b><br>\n            <label for=\"person\">Person</label>\n            <input type=\"text\" id=\"person\" name=\"person\" size=\"65\"  value=\"","\"><br>\n            <label for=\"position\">Position</label>\n            <input type=\"text\" id=\"position\" name=\"position\" size=\"65\"  value=\"","\"><br>\n            <label for=\"organization\">Organization</label>\n            <input type=\"text\" id=\"organization\" name=\"organization\" size=\"65\"  value=\"","\"><br>\n            <label for=\"city\">City</label>\n            <input type=\"text\" id=\"city\" name=\"city\" size=\"65\"  value=\"","\"><br>\n            <label for=\"postcode\">Postcode</label>\n            <input type=\"text\" id=\"postcode\" name=\"postcode\" size=\"65\"  value=\"","\"><br>\n            <label for=\"country\">Country</label>\n            <input type=\"text\" id=\"country\" name=\"country\" size=\"65\"  value=\"","\"><br>\n            <label for=\"email\">E-mail</label>\n            <input type=\"text\" id=\"email\" name=\"email\" size=\"65\"  value=\"","\"><br>\n            <button @click=\"","\">Save</button>\n            <button @click=\"","\">Reset to default</button>\n            "]);_templateObject6_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject6_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject5_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral([""]);_templateObject5_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject5_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject4_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["<mp-accordion @click=\"","\">Edit metadata</mp-accordion>\n            <div class=\"panel\">\n            ","\n            </div>\n            "]);_templateObject4_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject4_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject3_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;                \n            }\n            .panel {\n              margin-left: 20px;\n            }\n        "]);_templateObject3_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject3_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject2_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            <button class=\"accordion","\" @click=\"","\"><slot></slot></button>\n            "]);_templateObject2_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject2_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}function _templateObject_2b46c4105c5e11e9a640aba88724ddc3(){var data=babelHelpers.taggedTemplateLiteral(["\n            :host {\n                display: block;\n            }\n            .accordion {\n                background-color: #eee;\n                color: #444;\n                cursor: pointer;\n                padding: 18px;\n                width: 100%;\n                text-align: left;\n                border: none;\n                outline: none;\n                transition: 0.4s;\n                margin-top: 3px;\n                margni-bottom: 3px;\n                font-weight: bold;\n            }\n            .active, .accordion:hover {\n                background-color: #ccc;\n            }\n            .accordion:after {\n                content: '+'; \n                font-size: 13px;\n                color: #777;\n                float: right;\n                margin-left: 5px;\n            }\n            .active:after {\n                content: \"-\"; \n            }\n        "]);_templateObject_2b46c4105c5e11e9a640aba88724ddc3=function _templateObject_2b46c4105c5e11e9a640aba88724ddc3(){return data};return data}/**
@license
Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/var supportsAdoptingStyleSheets="adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype;_exports.supportsAdoptingStyleSheets$1=_exports.supportsAdoptingStyleSheets=supportsAdoptingStyleSheets;var constructionToken=Symbol(),CSSResult=/*#__PURE__*/function(){function CSSResult(cssText,safeToken){babelHelpers.classCallCheck(this,CSSResult);if(safeToken!==constructionToken){throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.")}this.cssText=cssText}// Note, this is a getter so that it's lazy. In practice, this means
// stylesheets are not created until the first element instance is made.
babelHelpers.createClass(CSSResult,[{key:"toString",value:function toString(){return this.cssText}},{key:"styleSheet",get:function get(){if(this._styleSheet===void 0){// Note, if `adoptedStyleSheets` is supported then we assume CSSStyleSheet
// is constructable.
if(supportsAdoptingStyleSheets){this._styleSheet=new CSSStyleSheet;this._styleSheet.replaceSync(this.cssText)}else{this._styleSheet=null}}return this._styleSheet}}]);return CSSResult}();_exports.CSSResult$1=_exports.CSSResult=CSSResult;/**
   * Wrap a value for interpolation in a css tagged template literal.
   *
   * This is unsafe because untrusted CSS text can be used to phone home
   * or exfiltrate data to an attacker controlled site. Take care to only use
   * this with trusted input.
   */var unsafeCSS=function unsafeCSS(value){return new CSSResult(value+"",constructionToken)};_exports.unsafeCSS$1=_exports.unsafeCSS=unsafeCSS;var textFromCSSResult=function textFromCSSResult(value){if(babelHelpers.instanceof(value,CSSResult)){return value.cssText}else{throw new Error("Value passed to 'css' function must be a 'css' function result: ".concat(value,". Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security."))}},css=function css(strings){for(var _len=arguments.length,values=Array(1<_len?_len-1:0),_key=1;_key<_len;_key++){values[_key-1]=arguments[_key]}var cssText=values.reduce(function(acc,v,idx){return acc+textFromCSSResult(v)+strings[idx+1]},strings[0]);return new CSSResult(cssText,constructionToken)};/**
    * Template tag which which can be used with LitElement's `style` property to
    * set element styles. For security reasons, only literal string values may be
    * used. To incorporate non-literal values `unsafeCSS` may be used inside a
    * template string part.
    */_exports.css$1=_exports.css=css;var cssTag={supportsAdoptingStyleSheets:supportsAdoptingStyleSheets,CSSResult:CSSResult,unsafeCSS:unsafeCSS,css:css};/**
    * @license
    * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */_exports.$cssTag=cssTag;var legacyCustomElement=function legacyCustomElement(tagName,clazz){window.customElements.define(tagName,clazz);// Cast as any because TS doesn't recognize the return type as being a
// subtype of the decorated class when clazz is typed as
// `Constructor<HTMLElement>` for some reason.
// `Constructor<HTMLElement>` is helpful to make sure the decorator is
// applied to elements however.
// tslint:disable-next-line:no-any
return clazz},standardCustomElement=function standardCustomElement(tagName,descriptor){var kind=descriptor.kind,elements=descriptor.elements;return{kind:kind,elements:elements,// This callback is called once the class is otherwise fully defined
finisher:function finisher(clazz){window.customElements.define(tagName,clazz)}}},customElement=function customElement(tagName){return function(classOrDescriptor){return"function"===typeof classOrDescriptor?legacyCustomElement(tagName,classOrDescriptor):standardCustomElement(tagName,classOrDescriptor)}};_exports.customElement$1=_exports.customElement=customElement;var standardProperty=function standardProperty(options,element){// When decorating an accessor, pass it through and add property metadata.
// Note, the `hasOwnProperty` check in `createProperty` ensures we don't
// stomp over the user's accessor.
if("method"===element.kind&&element.descriptor&&!("value"in element.descriptor)){return Object.assign({},element,{finisher:function finisher(clazz){clazz.createProperty(element.key,options)}})}else{// createProperty() takes care of defining the property, but we still
// must return some kind of descriptor, so return a descriptor for an
// unused prototype field. The finisher calls createProperty().
return{kind:"field",key:Symbol(),placement:"own",descriptor:{},// When @babel/plugin-proposal-decorators implements initializers,
// do this instead of the initializer below. See:
// https://github.com/babel/babel/issues/9260 extras: [
//   {
//     kind: 'initializer',
//     placement: 'own',
//     initializer: descriptor.initializer,
//   }
// ],
// tslint:disable-next-line:no-any decorator
initializer:function initializer(){if("function"===typeof element.initializer){this[element.key]=element.initializer.call(this)}},finisher:function finisher(clazz){clazz.createProperty(element.key,options)}}}},legacyProperty=function legacyProperty(options,proto,name){proto.constructor.createProperty(name,options)};/**
    * A property decorator which creates a LitElement property which reflects a
    * corresponding attribute value. A `PropertyDeclaration` may optionally be
    * supplied to configure property features.
    *
    * @ExportDecoratedItems
    */function property(options){// tslint:disable-next-line:no-any decorator
return function(protoOrDescriptor,name){return name!==void 0?legacyProperty(options,protoOrDescriptor,name):standardProperty(options,protoOrDescriptor)}}/**
   * A property decorator that converts a class property into a getter that
   * executes a querySelector on the element's renderRoot.
   */var query=_query(function(target,selector){return target.querySelector(selector)});/**
                                                                                    * A property decorator that converts a class property into a getter
                                                                                    * that executes a querySelectorAll on the element's renderRoot.
                                                                                    */_exports.query$1=_exports.query=query;var queryAll=_query(function(target,selector){return target.querySelectorAll(selector)});_exports.queryAll$1=_exports.queryAll=queryAll;var legacyQuery=function legacyQuery(descriptor,proto,name){Object.defineProperty(proto,name,descriptor)},standardQuery=function standardQuery(descriptor,element){return{kind:"method",placement:"prototype",key:element.key,descriptor:descriptor}};/**
     * Base-implementation of `@query` and `@queryAll` decorators.
     *
     * @param queryFn exectute a `selector` (ie, querySelector or querySelectorAll)
     * against `target`.
     * @suppress {visibility} The descriptor accesses an internal field on the
     * element.
     */function _query(queryFn){return function(selector){return function(protoOrDescriptor,// tslint:disable-next-line:no-any decorator
name){var descriptor={get:function get(){return queryFn(this.renderRoot,selector)},enumerable:!0,configurable:!0};return name!==void 0?legacyQuery(descriptor,protoOrDescriptor,name):standardQuery(descriptor,protoOrDescriptor)}}}var standardEventOptions=function standardEventOptions(options,element){return Object.assign({},element,{finisher:function finisher(clazz){Object.assign(clazz.prototype[element.key],options)}})},legacyEventOptions=// tslint:disable-next-line:no-any legacy decorator
function legacyEventOptions(options,proto,name){Object.assign(proto[name],options)},eventOptions=function eventOptions(options){return(// Return value typed as any to prevent TypeScript from complaining that
// standard decorator function signature does not match TypeScript decorator
// signature
// TODO(kschaaf): unclear why it was only failing on this decorator and not
// the others
function(protoOrDescriptor,name){return name!==void 0?legacyEventOptions(options,protoOrDescriptor,name):standardEventOptions(options,protoOrDescriptor)})};_exports.eventOptions$1=_exports.eventOptions=eventOptions;var decorators={customElement:customElement,property:property,query:query,queryAll:queryAll,eventOptions:eventOptions};/**
    * @license
    * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */ /**
        * When using Closure Compiler, JSCompiler_renameProperty(property, object) is
        * replaced at compile time by the munged name for object[property]. We cannot
        * alias this function, so we have to use a small shim that has the same
        * behavior when not compiling.
        */_exports.$decorators=decorators;window.JSCompiler_renameProperty=function(prop,_obj){return prop};var defaultConverter={toAttribute:function toAttribute(value,type){switch(type){case Boolean:return value?"":null;case Object:case Array:// if the value is `null` or `undefined` pass this through
// to allow removing/no change behavior.
return null==value?value:JSON.stringify(value);}return value},fromAttribute:function fromAttribute(value,type){switch(type){case Boolean:return null!==value;case Number:return null===value?null:+value;case Object:case Array:return JSON.parse(value);}return value}};/**
    * Change function that returns true if `value` is different from `oldValue`.
    * This method is used as the default for a property's `hasChanged` function.
    */_exports.defaultConverter$1=_exports.defaultConverter=defaultConverter;var notEqual=function notEqual(value,old){// This ensures (old==NaN, value==NaN) always returns false
return old!==value&&(old===old||value===value)};_exports.notEqual$1=_exports.notEqual=notEqual;var defaultPropertyDeclaration={attribute:!0,type:String,converter:defaultConverter,reflect:!1,hasChanged:notEqual},microtaskPromise=Promise.resolve(!0),STATE_HAS_UPDATED=1,STATE_UPDATE_REQUESTED=1<<2,STATE_IS_REFLECTING_TO_ATTRIBUTE=1<<3,STATE_IS_REFLECTING_TO_PROPERTY=1<<4,STATE_HAS_CONNECTED=1<<5,UpdatingElement=/*#__PURE__*/function(_HTMLElement){babelHelpers.inherits(UpdatingElement,_HTMLElement);function UpdatingElement(){var _this;babelHelpers.classCallCheck(this,UpdatingElement);_this=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(UpdatingElement).call(this));_this._updateState=0;_this._instanceProperties=void 0;_this._updatePromise=microtaskPromise;_this._hasConnectedResolver=void 0;/**
                                             * Map with keys for any properties that have changed since the last
                                             * update cycle with previous values.
                                             */_this._changedProperties=new Map;/**
                                          * Map with keys of properties that should be reflected when updated.
                                          */_this._reflectingProperties=void 0;_this.initialize();return _this}/**
     * Returns a list of attributes corresponding to the registered properties.
     * @nocollapse
     */babelHelpers.createClass(UpdatingElement,[{key:"initialize",/**
     * Performs element initialization. By default captures any pre-set values for
     * registered properties.
     */value:function initialize(){this._saveInstanceProperties()}/**
     * Fixes any properties set on the instance before upgrade time.
     * Otherwise these would shadow the accessor and break these properties.
     * The properties are stored in a Map which is played back after the
     * constructor runs. Note, on very old versions of Safari (<=9) or Chrome
     * (<=41), properties created for native platform properties like (`id` or
     * `name`) may not have default values set in the element constructor. On
     * these browsers native properties appear on instances and therefore their
     * default value will overwrite any element default (e.g. if the element sets
     * this.id = 'id' in the constructor, the 'id' will become '' since this is
     * the native platform default).
     */},{key:"_saveInstanceProperties",value:function _saveInstanceProperties(){var _this2=this;// Use forEach so this works even if for/of loops are compiled to for loops
// expecting arrays
this.constructor._classProperties.forEach(function(_v,p){if(_this2.hasOwnProperty(p)){var value=_this2[p];delete _this2[p];if(!_this2._instanceProperties){_this2._instanceProperties=new Map}_this2._instanceProperties.set(p,value)}})}/**
     * Applies previously saved instance properties.
     */},{key:"_applyInstanceProperties",value:function _applyInstanceProperties(){var _this3=this;// Use forEach so this works even if for/of loops are compiled to for loops
// expecting arrays
// tslint:disable-next-line:no-any
this._instanceProperties.forEach(function(v,p){return _this3[p]=v});this._instanceProperties=void 0}},{key:"connectedCallback",value:function connectedCallback(){this._updateState=this._updateState|STATE_HAS_CONNECTED;// Ensure connection triggers an update. Updates cannot complete before
// connection and if one is pending connection the `_hasConnectionResolver`
// will exist. If so, resolve it to complete the update, otherwise
// requestUpdate.
if(this._hasConnectedResolver){this._hasConnectedResolver();this._hasConnectedResolver=void 0}else{this.requestUpdate()}}/**
     * Allows for `super.disconnectedCallback()` in extensions while
     * reserving the possibility of making non-breaking feature additions
     * when disconnecting at some point in the future.
     */},{key:"disconnectedCallback",value:function disconnectedCallback(){}/**
                             * Synchronizes property values when attributes change.
                             */},{key:"attributeChangedCallback",value:function attributeChangedCallback(name,old,value){if(old!==value){this._attributeToProperty(name,value)}}},{key:"_propertyToAttribute",value:function _propertyToAttribute(name,value){var options=2<arguments.length&&arguments[2]!==void 0?arguments[2]:defaultPropertyDeclaration,ctor=this.constructor,attr=ctor._attributeNameForProperty(name,options);if(attr!==void 0){var attrValue=ctor._propertyValueToAttribute(value,options);// an undefined value does not change the attribute.
if(attrValue===void 0){return}// Track if the property is being reflected to avoid
// setting the property again via `attributeChangedCallback`. Note:
// 1. this takes advantage of the fact that the callback is synchronous.
// 2. will behave incorrectly if multiple attributes are in the reaction
// stack at time of calling. However, since we process attributes
// in `update` this should not be possible (or an extreme corner case
// that we'd like to discover).
// mark state reflecting
this._updateState=this._updateState|STATE_IS_REFLECTING_TO_ATTRIBUTE;if(null==attrValue){this.removeAttribute(attr)}else{this.setAttribute(attr,attrValue)}// mark state not reflecting
this._updateState=this._updateState&~STATE_IS_REFLECTING_TO_ATTRIBUTE}}},{key:"_attributeToProperty",value:function _attributeToProperty(name,value){// Use tracking info to avoid deserializing attribute value if it was
// just set from a property setter.
if(this._updateState&STATE_IS_REFLECTING_TO_ATTRIBUTE){return}var ctor=this.constructor,propName=ctor._attributeToPropertyMap.get(name);if(propName!==void 0){var options=ctor._classProperties.get(propName)||defaultPropertyDeclaration;// mark state reflecting
this._updateState=this._updateState|STATE_IS_REFLECTING_TO_PROPERTY;this[propName]=// tslint:disable-next-line:no-any
ctor._propertyValueFromAttribute(value,options);// mark state not reflecting
this._updateState=this._updateState&~STATE_IS_REFLECTING_TO_PROPERTY}}/**
     * Requests an update which is processed asynchronously. This should
     * be called when an element should update based on some state not triggered
     * by setting a property. In this case, pass no arguments. It should also be
     * called when manually implementing a property setter. In this case, pass the
     * property `name` and `oldValue` to ensure that any configured property
     * options are honored. Returns the `updateComplete` Promise which is resolved
     * when the update completes.
     *
     * @param name {PropertyKey} (optional) name of requesting property
     * @param oldValue {any} (optional) old value of requesting property
     * @returns {Promise} A Promise that is resolved when the update completes.
     */},{key:"requestUpdate",value:function requestUpdate(name,oldValue){var shouldRequestUpdate=!0;// if we have a property key, perform property update steps.
if(name!==void 0&&!this._changedProperties.has(name)){var ctor=this.constructor,options=ctor._classProperties.get(name)||defaultPropertyDeclaration;if(ctor._valueHasChanged(this[name],oldValue,options.hasChanged)){// track old value when changing.
this._changedProperties.set(name,oldValue);// add to reflecting properties set
if(!0===options.reflect&&!(this._updateState&STATE_IS_REFLECTING_TO_PROPERTY)){if(this._reflectingProperties===void 0){this._reflectingProperties=new Map}this._reflectingProperties.set(name,options)}// abort the request if the property should not be considered changed.
}else{shouldRequestUpdate=!1}}if(!this._hasRequestedUpdate&&shouldRequestUpdate){this._enqueueUpdate()}return this.updateComplete}/**
     * Sets up the element to asynchronously update.
     */},{key:"_enqueueUpdate",value:function(){var _enqueueUpdate2=babelHelpers.asyncToGenerator(/*#__PURE__*/regeneratorRuntime.mark(function _callee(){var _this4=this,resolve,previousUpdatePromise,result;return regeneratorRuntime.wrap(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:// Mark state updating...
this._updateState=this._updateState|STATE_UPDATE_REQUESTED;previousUpdatePromise=this._updatePromise;this._updatePromise=new Promise(function(res){return resolve=res});// Ensure any previous update has resolved before updating.
// This `await` also ensures that property changes are batched.
_context.next=5;return previousUpdatePromise;case 5:if(this._hasConnected){_context.next=8;break}_context.next=8;return new Promise(function(res){return _this4._hasConnectedResolver=res});case 8:// Allow `performUpdate` to be asynchronous to enable scheduling of updates.
result=this.performUpdate();// Note, this is to avoid delaying an additional microtask unless we need
// to.
if(!(null!=result&&"function"===typeof result.then)){_context.next=12;break}_context.next=12;return result;case 12:resolve(!this._hasRequestedUpdate);case 13:case"end":return _context.stop();}}},_callee,this)}));function _enqueueUpdate(){return _enqueueUpdate2.apply(this,arguments)}return _enqueueUpdate}()},{key:"performUpdate",/**
     * Performs an element update.
     *
     * You can override this method to change the timing of updates. For instance,
     * to schedule updates to occur just before the next frame:
     *
     * ```
     * protected async performUpdate(): Promise<unknown> {
     *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
     *   super.performUpdate();
     * }
     * ```
     */value:function performUpdate(){// Mixin instance properties once, if they exist.
if(this._instanceProperties){this._applyInstanceProperties()}if(this.shouldUpdate(this._changedProperties)){var changedProperties=this._changedProperties;this.update(changedProperties);this._markUpdated();if(!(this._updateState&STATE_HAS_UPDATED)){this._updateState=this._updateState|STATE_HAS_UPDATED;this.firstUpdated(changedProperties)}this.updated(changedProperties)}else{this._markUpdated()}}},{key:"_markUpdated",value:function _markUpdated(){this._changedProperties=new Map;this._updateState=this._updateState&~STATE_UPDATE_REQUESTED}/**
     * Returns a Promise that resolves when the element has completed updating.
     * The Promise value is a boolean that is `true` if the element completed the
     * update without triggering another update. The Promise result is `false` if
     * a property was set inside `updated()`. This getter can be implemented to
     * await additional state. For example, it is sometimes useful to await a
     * rendered element before fulfilling this Promise. To do this, first await
     * `super.updateComplete` then any subsequent state.
     *
     * @returns {Promise} The Promise returns a boolean that indicates if the
     * update resolved without triggering another update.
     */},{key:"shouldUpdate",/**
     * Controls whether or not `update` should be called when the element requests
     * an update. By default, this method always returns `true`, but this can be
     * customized to control when to update.
     *
     * * @param _changedProperties Map of changed properties with old values
     */value:function shouldUpdate(_changedProperties){return!0}/**
     * Updates the element. This method reflects property values to attributes.
     * It can be overridden to render and keep updated element DOM.
     * Setting properties inside this method will *not* trigger
     * another update.
     *
     * * @param _changedProperties Map of changed properties with old values
     */},{key:"update",value:function update(_changedProperties){var _this5=this;if(this._reflectingProperties!==void 0&&0<this._reflectingProperties.size){// Use forEach so this works even if for/of loops are compiled to for
// loops expecting arrays
this._reflectingProperties.forEach(function(v,k){return _this5._propertyToAttribute(k,_this5[k],v)});this._reflectingProperties=void 0}}/**
     * Invoked whenever the element is updated. Implement to perform
     * post-updating tasks via DOM APIs, for example, focusing an element.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * * @param _changedProperties Map of changed properties with old values
     */},{key:"updated",value:function updated(_changedProperties){}/**
                                  * Invoked when the element is first updated. Implement to perform one time
                                  * work on the element after update.
                                  *
                                  * Setting properties inside this method will trigger the element to update
                                  * again after this update cycle completes.
                                  *
                                  * * @param _changedProperties Map of changed properties with old values
                                  */},{key:"firstUpdated",value:function firstUpdated(_changedProperties){}},{key:"_hasConnected",get:function get(){return this._updateState&STATE_HAS_CONNECTED}},{key:"_hasRequestedUpdate",get:function get(){return this._updateState&STATE_UPDATE_REQUESTED}},{key:"hasUpdated",get:function get(){return this._updateState&STATE_HAS_UPDATED}},{key:"updateComplete",get:function get(){return this._updatePromise}}],[{key:"_ensureClassProperties",/**
     * Ensures the private `_classProperties` property metadata is created.
     * In addition to `finalize` this is also called in `createProperty` to
     * ensure the `@property` decorator can add property metadata.
     */ /** @nocollapse */value:function _ensureClassProperties(){var _this6=this;// ensure private storage for property declarations.
if(!this.hasOwnProperty(JSCompiler_renameProperty("_classProperties",this))){this._classProperties=new Map;// NOTE: Workaround IE11 not supporting Map constructor argument.
var superProperties=Object.getPrototypeOf(this)._classProperties;if(superProperties!==void 0){superProperties.forEach(function(v,k){return _this6._classProperties.set(k,v)})}}}/**
     * Creates a property accessor on the element prototype if one does not exist.
     * The property setter calls the property's `hasChanged` property option
     * or uses a strict identity check to determine whether or not to request
     * an update.
     * @nocollapse
     */},{key:"createProperty",value:function createProperty(name){var options=1<arguments.length&&arguments[1]!==void 0?arguments[1]:defaultPropertyDeclaration;// Note, since this can be called by the `@property` decorator which
// is called before `finalize`, we ensure storage exists for property
// metadata.
this._ensureClassProperties();this._classProperties.set(name,options);// Do not generate an accessor if the prototype already has one, since
// it would be lost otherwise and that would never be the user's intention;
// Instead, we expect users to call `requestUpdate` themselves from
// user-defined accessors. Note that if the super has an accessor we will
// still overwrite it
if(options.noAccessor||this.prototype.hasOwnProperty(name)){return}var key="symbol"===babelHelpers.typeof(name)?Symbol():"__".concat(name);Object.defineProperty(this.prototype,name,{// tslint:disable-next-line:no-any no symbol in index
get:function get(){// tslint:disable-next-line:no-any no symbol in index
return this[key]},set:function set(value){// tslint:disable-next-line:no-any no symbol in index
var oldValue=this[name];// tslint:disable-next-line:no-any no symbol in index
this[key]=value;this.requestUpdate(name,oldValue)},configurable:!0,enumerable:!0})}/**
     * Creates property accessors for registered properties and ensures
     * any superclasses are also finalized.
     * @nocollapse
     */},{key:"finalize",value:function finalize(){if(this.hasOwnProperty(JSCompiler_renameProperty("finalized",this))&&this.finalized){return}// finalize any superclasses
var superCtor=Object.getPrototypeOf(this);if("function"===typeof superCtor.finalize){superCtor.finalize()}this.finalized=!0;this._ensureClassProperties();// initialize Map populated in observedAttributes
this._attributeToPropertyMap=new Map;// make any properties
// Note, only process "own" properties since this element will inherit
// any properties defined on the superClass, and finalization ensures
// the entire prototype chain is finalized.
if(this.hasOwnProperty(JSCompiler_renameProperty("properties",this))){var props=this.properties,propKeys=[].concat(babelHelpers.toConsumableArray(Object.getOwnPropertyNames(props)),babelHelpers.toConsumableArray("function"===typeof Object.getOwnPropertySymbols?Object.getOwnPropertySymbols(props):[])),_iteratorNormalCompletion=!0,_didIteratorError=!1,_iteratorError=void 0;// support symbols in properties (IE11 does not support this)
try{// This for/of is ok because propKeys is an array
for(var _iterator=propKeys[Symbol.iterator](),_step,p;!(_iteratorNormalCompletion=(_step=_iterator.next()).done);_iteratorNormalCompletion=!0){p=_step.value;// note, use of `any` is due to TypeSript lack of support for symbol in
// index types
// tslint:disable-next-line:no-any no symbol in index
this.createProperty(p,props[p])}}catch(err){_didIteratorError=!0;_iteratorError=err}finally{try{if(!_iteratorNormalCompletion&&null!=_iterator.return){_iterator.return()}}finally{if(_didIteratorError){throw _iteratorError}}}}}/**
     * Returns the property name for the given attribute `name`.
     * @nocollapse
     */},{key:"_attributeNameForProperty",value:function _attributeNameForProperty(name,options){var attribute=options.attribute;return!1===attribute?void 0:"string"===typeof attribute?attribute:"string"===typeof name?name.toLowerCase():void 0}/**
     * Returns true if a property should request an update.
     * Called when a property value is set and uses the `hasChanged`
     * option for the property if present or a strict identity check.
     * @nocollapse
     */},{key:"_valueHasChanged",value:function _valueHasChanged(value,old){var hasChanged=2<arguments.length&&arguments[2]!==void 0?arguments[2]:notEqual;return hasChanged(value,old)}/**
     * Returns the property value for the given attribute value.
     * Called via the `attributeChangedCallback` and uses the property's
     * `converter` or `converter.fromAttribute` property option.
     * @nocollapse
     */},{key:"_propertyValueFromAttribute",value:function _propertyValueFromAttribute(value,options){var type=options.type,converter=options.converter||defaultConverter,fromAttribute="function"===typeof converter?converter:converter.fromAttribute;return fromAttribute?fromAttribute(value,type):value}/**
     * Returns the attribute value for the given property value. If this
     * returns undefined, the property will *not* be reflected to an attribute.
     * If this returns null, the attribute will be removed, otherwise the
     * attribute will be set to the value.
     * This uses the property's `reflect` and `type.toAttribute` property options.
     * @nocollapse
     */},{key:"_propertyValueToAttribute",value:function _propertyValueToAttribute(value,options){if(options.reflect===void 0){return}var type=options.type,converter=options.converter,toAttribute=converter&&converter.toAttribute||defaultConverter.toAttribute;return toAttribute(value,type)}},{key:"observedAttributes",get:function get(){var _this7=this;// note: piggy backing on this to ensure we're finalized.
this.finalize();var attributes=[];// Use forEach so this works even if for/of loops are compiled to for loops
// expecting arrays
this._classProperties.forEach(function(v,p){var attr=_this7._attributeNameForProperty(p,v);if(attr!==void 0){_this7._attributeToPropertyMap.set(attr,p);attributes.push(attr)}});return attributes}}]);return UpdatingElement}(babelHelpers.wrapNativeSuper(HTMLElement));_exports.UpdatingElement$1=_exports.UpdatingElement=UpdatingElement;/**
   * Marks class as having finished creating properties.
   */UpdatingElement.finalized=!0;var updatingElement={defaultConverter:defaultConverter,notEqual:notEqual,UpdatingElement:UpdatingElement};/**
    * @license
    * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */_exports.$updatingElement=updatingElement;var directives=new WeakMap,directive=function directive(f){return function(){var d=f.apply(void 0,arguments);directives.set(d,!0);return d}};/**
                                   * Brands a function as a directive so that lit-html will call the function
                                   * during template rendering, rather than passing as a value.
                                   *
                                   * @param f The directive factory function. Must be a function that returns a
                                   * function of the signature `(part: Part) => void`. The returned function will
                                   * be called with the part object
                                   *
                                   * @example
                                   *
                                   * ```
                                   * import {directive, html} from 'lit-html';
                                   *
                                   * const immutable = directive((v) => (part) => {
                                   *   if (part.value !== v) {
                                   *     part.setValue(v)
                                   *   }
                                   * });
                                   * ```
                                   */ // tslint:disable-next-line:no-any
_exports.directive$1=_exports.directive=directive;var isDirective=function isDirective(o){return"function"===typeof o&&directives.has(o)};_exports.isDirective$1=_exports.isDirective=isDirective;var directive$1={directive:directive,isDirective:isDirective};/**
    * @license
    * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */ /**
        * True if the custom elements polyfill is in use.
        */_exports.$directive=directive$1;var isCEPolyfill=window.customElements!==void 0&&window.customElements.polyfillWrapFlushCallback!==void 0;/**
                                                                                                                                   * Reparents nodes, starting from `startNode` (inclusive) to `endNode`
                                                                                                                                   * (exclusive), into another container (could be the same container), before
                                                                                                                                   * `beforeNode`. If `beforeNode` is null, it appends the nodes to the
                                                                                                                                   * container.
                                                                                                                                   */_exports.isCEPolyfill=isCEPolyfill;var reparentNodes=function reparentNodes(container,start){var end=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null,before=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null,node=start;while(node!==end){var n=node.nextSibling;container.insertBefore(node,before);node=n}};/**
    * Removes nodes, starting from `startNode` (inclusive) to `endNode`
    * (exclusive), from `container`.
    */_exports.reparentNodes$1=_exports.reparentNodes=reparentNodes;var removeNodes=function removeNodes(container,startNode){var endNode=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null,node=startNode;while(node!==endNode){var n=node.nextSibling;container.removeChild(node);node=n}};_exports.removeNodes$1=_exports.removeNodes=removeNodes;var dom={isCEPolyfill:isCEPolyfill,reparentNodes:reparentNodes,removeNodes:removeNodes};/**
    * @license
    * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */ /**
        * A sentinel value that signals that a value was handled by a directive and
        * should not be written to the DOM.
        */_exports.$dom=dom;var noChange={};/**
                             * A sentinel value that signals a NodePart to fully clear its content.
                             */_exports.noChange$1=_exports.noChange=noChange;var nothing={};_exports.nothing$1=_exports.nothing=nothing;var part={noChange:noChange,nothing:nothing};/**
    * @license
    * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
    * This code may only be used under the BSD style license found at
    * http://polymer.github.io/LICENSE.txt
    * The complete set of authors may be found at
    * http://polymer.github.io/AUTHORS.txt
    * The complete set of contributors may be found at
    * http://polymer.github.io/CONTRIBUTORS.txt
    * Code distributed by Google as part of the polymer project is also
    * subject to an additional IP rights grant found at
    * http://polymer.github.io/PATENTS.txt
    */ /**
        * An expression marker with embedded unique key to avoid collision with
        * possible text in templates.
        */_exports.$part=part;var marker="{{lit-".concat((Math.random()+"").slice(2),"}}");/**
                                                                    * An expression marker used text-positions, multi-binding attributes, and
                                                                    * attributes with markup-like text values.
                                                                    */_exports.marker=marker;var nodeMarker="<!--".concat(marker,"-->");_exports.nodeMarker=nodeMarker;var markerRegex=new RegExp("".concat(marker,"|").concat(nodeMarker));/**
                                                                   * Suffix appended to all bound attribute names.
                                                                   */_exports.markerRegex=markerRegex;var boundAttributeSuffix="$lit$";/**
                                              * An updateable Template that tracks the location of dynamic parts.
                                              */_exports.boundAttributeSuffix=boundAttributeSuffix;var Template=function Template(result,element){var _this8=this;babelHelpers.classCallCheck(this,Template);this.parts=[];this.element=element;var index=-1,partIndex=0,nodesToRemove=[],_prepareTemplate=function _prepareTemplate(template){var content=template.content,walker=document.createTreeWalker(content,133/* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */,null,!1),lastPartIndex=0;// Edge needs all 4 parameters present; IE11 needs 3rd parameter to be
// null
while(walker.nextNode()){index++;var node=walker.currentNode;if(1===node.nodeType/* Node.ELEMENT_NODE */){if(node.hasAttributes()){for(var attributes=node.attributes,count=0,i=0;i<attributes.length;i++){if(0<=attributes[i].value.indexOf(marker)){count++}}while(0<count--){// Get the template literal section leading up to the first
// expression in this attribute
var stringForPart=result.strings[partIndex],name=lastAttributeNameRegex.exec(stringForPart)[2],attributeLookupName=name.toLowerCase()+boundAttributeSuffix,attributeValue=node.getAttribute(attributeLookupName),strings=attributeValue.split(markerRegex);// Find the attribute name
_this8.parts.push({type:"attribute",index:index,name:name,strings:strings});node.removeAttribute(attributeLookupName);partIndex+=strings.length-1}}if("TEMPLATE"===node.tagName){_prepareTemplate(node)}}else if(3===node.nodeType/* Node.TEXT_NODE */){var data=node.data;if(0<=data.indexOf(marker)){// Generate a new text node for each literal section
// These nodes are also used as the markers for node parts
for(var parent=node.parentNode,_strings=data.split(markerRegex),lastIndex=_strings.length-1,_i=0;_i<lastIndex;_i++){parent.insertBefore(""===_strings[_i]?createMarker():document.createTextNode(_strings[_i]),node);_this8.parts.push({type:"node",index:++index})}// If there's no text, we must insert a comment to mark our place.
// Else, we can trust it will stick around after cloning.
if(""===_strings[lastIndex]){parent.insertBefore(createMarker(),node);nodesToRemove.push(node)}else{node.data=_strings[lastIndex]}// We have a part for each match found
partIndex+=lastIndex}}else if(8===node.nodeType/* Node.COMMENT_NODE */){if(node.data===marker){var _parent=node.parentNode;// Add a new marker node to be the startNode of the Part if any of
// the following are true:
//  * We don't have a previousSibling
//  * The previousSibling is already the start of a previous part
if(null===node.previousSibling||index===lastPartIndex){index++;_parent.insertBefore(createMarker(),node)}lastPartIndex=index;_this8.parts.push({type:"node",index:index});// If we don't have a nextSibling, keep this node so we have an end.
// Else, we can remove it to save future costs.
if(null===node.nextSibling){node.data=""}else{nodesToRemove.push(node);index--}partIndex++}else{var _i2=-1;while(-1!==(_i2=node.data.indexOf(marker,_i2+1))){// Comment node has a binding marker inside, make an inactive part
// The binding won't work, but subsequent bindings will
// TODO (justinfagnani): consider whether it's even worth it to
// make bindings in comments work
_this8.parts.push({type:"node",index:-1})}}}}};_prepareTemplate(element);// Remove text binding nodes after the walk to not disturb the TreeWalker
for(var _arr=nodesToRemove,_i3=0,n;_i3<_arr.length;_i3++){n=_arr[_i3];n.parentNode.removeChild(n)}};_exports.Template$1=_exports.Template=Template;var isTemplatePartActive=function isTemplatePartActive(part){return-1!==part.index};// Allows `document.createComment('')` to be renamed for a
// small manual size-savings.
_exports.isTemplatePartActive$1=_exports.isTemplatePartActive=isTemplatePartActive;var createMarker=function createMarker(){return document.createComment("")};/**
                                                               * This regex extracts the attribute name preceding an attribute-position
                                                               * expression. It does this by matching the syntax allowed for attributes
                                                               * against the string literal directly preceding the expression, assuming that
                                                               * the expression is in an attribute-value position.
                                                               *
                                                               * See attributes in the HTML spec:
                                                               * https://www.w3.org/TR/html5/syntax.html#attributes-0
                                                               *
                                                               * "\0-\x1F\x7F-\x9F" are Unicode control characters
                                                               *
                                                               * " \x09\x0a\x0c\x0d" are HTML space characters:
                                                               * https://www.w3.org/TR/html5/infrastructure.html#space-character
                                                               *
                                                               * So an attribute is:
                                                               *  * The name: any character except a control character, space character, ('),
                                                               *    ("), ">", "=", or "/"
                                                               *  * Followed by zero or more space characters
                                                               *  * Followed by "="
                                                               *  * Followed by zero or more space characters
                                                               *  * Followed by:
                                                               *    * Any character except space, ('), ("), "<", ">", "=", (`), or
                                                               *    * (") then any non-("), or
                                                               *    * (') then any non-(')
                                                               */_exports.createMarker$1=_exports.createMarker=createMarker;var lastAttributeNameRegex=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F \x09\x0a\x0c\x0d"'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;_exports.lastAttributeNameRegex=lastAttributeNameRegex;var template={marker:marker,nodeMarker:nodeMarker,markerRegex:markerRegex,boundAttributeSuffix:boundAttributeSuffix,Template:Template,isTemplatePartActive:isTemplatePartActive,createMarker:createMarker,lastAttributeNameRegex:lastAttributeNameRegex};_exports.$template=template;var TemplateInstance=/*#__PURE__*/function(){function TemplateInstance(template,processor,options){babelHelpers.classCallCheck(this,TemplateInstance);this._parts=[];this.template=template;this.processor=processor;this.options=options}babelHelpers.createClass(TemplateInstance,[{key:"update",value:function update(values){var i=0,_iteratorNormalCompletion2=!0,_didIteratorError2=!1,_iteratorError2=void 0;try{for(var _iterator2=this._parts[Symbol.iterator](),_step2,_part;!(_iteratorNormalCompletion2=(_step2=_iterator2.next()).done);_iteratorNormalCompletion2=!0){_part=_step2.value;if(_part!==void 0){_part.setValue(values[i])}i++}}catch(err){_didIteratorError2=!0;_iteratorError2=err}finally{try{if(!_iteratorNormalCompletion2&&null!=_iterator2.return){_iterator2.return()}}finally{if(_didIteratorError2){throw _iteratorError2}}}var _iteratorNormalCompletion3=!0,_didIteratorError3=!1,_iteratorError3=void 0;try{for(var _iterator3=this._parts[Symbol.iterator](),_step3,_part2;!(_iteratorNormalCompletion3=(_step3=_iterator3.next()).done);_iteratorNormalCompletion3=!0){_part2=_step3.value;if(_part2!==void 0){_part2.commit()}}}catch(err){_didIteratorError3=!0;_iteratorError3=err}finally{try{if(!_iteratorNormalCompletion3&&null!=_iterator3.return){_iterator3.return()}}finally{if(_didIteratorError3){throw _iteratorError3}}}}},{key:"_clone",value:function _clone(){var _this9=this,fragment=isCEPolyfill?this.template.element.content.cloneNode(!0):document.importNode(this.template.element.content,!0),parts=this.template.parts,partIndex=0,nodeIndex=0,_prepareInstance=function _prepareInstance(fragment){// Edge needs all 4 parameters present; IE11 needs 3rd parameter to be
// null
var walker=document.createTreeWalker(fragment,133/* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */,null,!1),node=walker.nextNode();// Loop through all the nodes and parts of a template
while(partIndex<parts.length&&null!==node){var _part3=parts[partIndex];// Consecutive Parts may have the same node index, in the case of
// multiple bound attributes on an element. So each iteration we either
// increment the nodeIndex, if we aren't on a node with a part, or the
// partIndex if we are. By not incrementing the nodeIndex when we find a
// part, we allow for the next part to be associated with the current
// node if neccessasry.
if(!isTemplatePartActive(_part3)){_this9._parts.push(void 0);partIndex++}else if(nodeIndex===_part3.index){if("node"===_part3.type){var _part4=_this9.processor.handleTextExpression(_this9.options);_part4.insertAfterNode(node.previousSibling);_this9._parts.push(_part4)}else{var _this9$_parts;(_this9$_parts=_this9._parts).push.apply(_this9$_parts,babelHelpers.toConsumableArray(_this9.processor.handleAttributeExpressions(node,_part3.name,_part3.strings,_this9.options)))}partIndex++}else{nodeIndex++;if("TEMPLATE"===node.nodeName){_prepareInstance(node.content)}node=walker.nextNode()}}};_prepareInstance(fragment);if(isCEPolyfill){document.adoptNode(fragment);customElements.upgrade(fragment)}return fragment}}]);return TemplateInstance}();_exports.TemplateInstance$1=_exports.TemplateInstance=TemplateInstance;var templateInstance={TemplateInstance:TemplateInstance};_exports.$templateInstance=templateInstance;var TemplateResult=/*#__PURE__*/function(){function TemplateResult(strings,values,type,processor){babelHelpers.classCallCheck(this,TemplateResult);this.strings=strings;this.values=values;this.type=type;this.processor=processor}/**
     * Returns a string of HTML used to create a `<template>` element.
     */babelHelpers.createClass(TemplateResult,[{key:"getHTML",value:function getHTML(){for(var endIndex=this.strings.length-1,html="",i=0;i<endIndex;i++){var s=this.strings[i],match=lastAttributeNameRegex.exec(s);// This exec() call does two things:
// 1) Appends a suffix to the bound attribute name to opt out of special
// attribute value parsing that IE11 and Edge do, like for style and
// many SVG attributes. The Template class also appends the same suffix
// when looking up attributes to create Parts.
// 2) Adds an unquoted-attribute-safe marker for the first expression in
// an attribute. Subsequent attribute expressions will use node markers,
// and this is safe since attributes with multiple expressions are
// guaranteed to be quoted.
if(match){// We're starting a new bound attribute.
// Add the safe attribute suffix, and use unquoted-attribute-safe
// marker.
html+=s.substr(0,match.index)+match[1]+match[2]+boundAttributeSuffix+match[3]+marker}else{// We're either in a bound node, or trailing bound attribute.
// Either way, nodeMarker is safe to use.
html+=s+nodeMarker}}return html+this.strings[endIndex]}},{key:"getTemplateElement",value:function getTemplateElement(){var template=document.createElement("template");template.innerHTML=this.getHTML();return template}}]);return TemplateResult}();/**
   * A TemplateResult for SVG fragments.
   *
   * This class wraps HTMl in an `<svg>` tag in order to parse its contents in the
   * SVG namespace, then modifies the template to remove the `<svg>` tag so that
   * clones only container the original fragment.
   */_exports.TemplateResult$3=_exports.TemplateResult$2=_exports.TemplateResult$1=_exports.TemplateResult=TemplateResult;var SVGTemplateResult=/*#__PURE__*/function(_TemplateResult){babelHelpers.inherits(SVGTemplateResult,_TemplateResult);function SVGTemplateResult(){babelHelpers.classCallCheck(this,SVGTemplateResult);return babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(SVGTemplateResult).apply(this,arguments))}babelHelpers.createClass(SVGTemplateResult,[{key:"getHTML",value:function getHTML(){return"<svg>".concat(babelHelpers.get(babelHelpers.getPrototypeOf(SVGTemplateResult.prototype),"getHTML",this).call(this),"</svg>")}},{key:"getTemplateElement",value:function getTemplateElement(){var template=babelHelpers.get(babelHelpers.getPrototypeOf(SVGTemplateResult.prototype),"getTemplateElement",this).call(this),content=template.content,svgElement=content.firstChild;content.removeChild(svgElement);reparentNodes(content,svgElement.firstChild);return template}}]);return SVGTemplateResult}(TemplateResult);_exports.SVGTemplateResult$2=_exports.SVGTemplateResult$1=_exports.SVGTemplateResult=SVGTemplateResult;var templateResult={TemplateResult:TemplateResult,SVGTemplateResult:SVGTemplateResult};_exports.$templateResult=templateResult;var isPrimitive=function isPrimitive(value){return null===value||!("object"===babelHelpers.typeof(value)||"function"===typeof value)};/**
    * Sets attribute values for AttributeParts, so that the value is only set once
    * even if there are multiple parts for an attribute.
    */_exports.isPrimitive$1=_exports.isPrimitive=isPrimitive;var AttributeCommitter=/*#__PURE__*/function(){function AttributeCommitter(element,name,strings){babelHelpers.classCallCheck(this,AttributeCommitter);this.dirty=!0;this.element=element;this.name=name;this.strings=strings;this.parts=[];for(var i=0;i<strings.length-1;i++){this.parts[i]=this._createPart()}}/**
     * Creates a single part. Override this to create a differnt type of part.
     */babelHelpers.createClass(AttributeCommitter,[{key:"_createPart",value:function _createPart(){return new AttributePart(this)}},{key:"_getValue",value:function _getValue(){for(var strings=this.strings,l=strings.length-1,text="",i=0;i<l;i++){text+=strings[i];var _part5=this.parts[i];if(_part5!==void 0){var v=_part5.value;if(null!=v&&(Array.isArray(v)||// tslint:disable-next-line:no-any
"string"!==typeof v&&v[Symbol.iterator])){var _iteratorNormalCompletion4=!0,_didIteratorError4=!1,_iteratorError4=void 0;try{for(var _iterator4=v[Symbol.iterator](),_step4,t;!(_iteratorNormalCompletion4=(_step4=_iterator4.next()).done);_iteratorNormalCompletion4=!0){t=_step4.value;text+="string"===typeof t?t:t+""}}catch(err){_didIteratorError4=!0;_iteratorError4=err}finally{try{if(!_iteratorNormalCompletion4&&null!=_iterator4.return){_iterator4.return()}}finally{if(_didIteratorError4){throw _iteratorError4}}}}else{text+="string"===typeof v?v:v+""}}}text+=strings[l];return text}},{key:"commit",value:function commit(){if(this.dirty){this.dirty=!1;this.element.setAttribute(this.name,this._getValue())}}}]);return AttributeCommitter}();_exports.AttributeCommitter$1=_exports.AttributeCommitter=AttributeCommitter;var AttributePart=/*#__PURE__*/function(){function AttributePart(comitter){babelHelpers.classCallCheck(this,AttributePart);this.value=void 0;this.committer=comitter}babelHelpers.createClass(AttributePart,[{key:"setValue",value:function setValue(value){if(value!==noChange&&(!isPrimitive(value)||value!==this.value)){this.value=value;// If the value is a not a directive, dirty the committer so that it'll
// call setAttribute. If the value is a directive, it'll dirty the
// committer if it calls setValue().
if(!isDirective(value)){this.committer.dirty=!0}}}},{key:"commit",value:function commit(){while(isDirective(this.value)){var _directive=this.value;this.value=noChange;_directive(this)}if(this.value===noChange){return}this.committer.commit()}}]);return AttributePart}();_exports.AttributePart$1=_exports.AttributePart=AttributePart;var NodePart=/*#__PURE__*/function(){function NodePart(options){babelHelpers.classCallCheck(this,NodePart);this.value=void 0;this._pendingValue=void 0;this.options=options}/**
     * Inserts this part into a container.
     *
     * This part must be empty, as its contents are not automatically moved.
     */babelHelpers.createClass(NodePart,[{key:"appendInto",value:function appendInto(container){this.startNode=container.appendChild(createMarker());this.endNode=container.appendChild(createMarker())}/**
     * Inserts this part between `ref` and `ref`'s next sibling. Both `ref` and
     * its next sibling must be static, unchanging nodes such as those that appear
     * in a literal section of a template.
     *
     * This part must be empty, as its contents are not automatically moved.
     */},{key:"insertAfterNode",value:function insertAfterNode(ref){this.startNode=ref;this.endNode=ref.nextSibling}/**
     * Appends this part into a parent part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */},{key:"appendIntoPart",value:function appendIntoPart(part){part._insert(this.startNode=createMarker());part._insert(this.endNode=createMarker())}/**
     * Appends this part after `ref`
     *
     * This part must be empty, as its contents are not automatically moved.
     */},{key:"insertAfterPart",value:function insertAfterPart(ref){ref._insert(this.startNode=createMarker());this.endNode=ref.endNode;ref.endNode=this.startNode}},{key:"setValue",value:function setValue(value){this._pendingValue=value}},{key:"commit",value:function commit(){while(isDirective(this._pendingValue)){var _directive2=this._pendingValue;this._pendingValue=noChange;_directive2(this)}var value=this._pendingValue;if(value===noChange){return}if(isPrimitive(value)){if(value!==this.value){this._commitText(value)}}else if(babelHelpers.instanceof(value,TemplateResult)){this._commitTemplateResult(value)}else if(babelHelpers.instanceof(value,Node)){this._commitNode(value)}else if(Array.isArray(value)||// tslint:disable-next-line:no-any
value[Symbol.iterator]){this._commitIterable(value)}else if(value===nothing){this.value=nothing;this.clear()}else{// Fallback, will render the string representation
this._commitText(value)}}},{key:"_insert",value:function _insert(node){this.endNode.parentNode.insertBefore(node,this.endNode)}},{key:"_commitNode",value:function _commitNode(value){if(this.value===value){return}this.clear();this._insert(value);this.value=value}},{key:"_commitText",value:function _commitText(value){var node=this.startNode.nextSibling;value=null==value?"":value;if(node===this.endNode.previousSibling&&3===node.nodeType/* Node.TEXT_NODE */){// If we only have a single text node between the markers, we can just
// set its value, rather than replacing it.
// TODO(justinfagnani): Can we just check if this.value is primitive?
node.data=value}else{this._commitNode(document.createTextNode("string"===typeof value?value:value+""))}this.value=value}},{key:"_commitTemplateResult",value:function _commitTemplateResult(value){var template=this.options.templateFactory(value);if(babelHelpers.instanceof(this.value,TemplateInstance)&&this.value.template===template){this.value.update(value.values)}else{// Make sure we propagate the template processor from the TemplateResult
// so that we use its syntax extension, etc. The template factory comes
// from the render function options so that it can control template
// caching and preprocessing.
var instance=new TemplateInstance(template,value.processor,this.options),fragment=instance._clone();instance.update(value.values);this._commitNode(fragment);this.value=instance}}},{key:"_commitIterable",value:function _commitIterable(value){// For an Iterable, we create a new InstancePart per item, then set its
// value to the item. This is a little bit of overhead for every item in
// an Iterable, but it lets us recurse easily and efficiently update Arrays
// of TemplateResults that will be commonly returned from expressions like:
// array.map((i) => html`${i}`), by reusing existing TemplateInstances.
// If _value is an array, then the previous render was of an
// iterable and _value will contain the NodeParts from the previous
// render. If _value is not an array, clear this part and make a new
// array for NodeParts.
if(!Array.isArray(this.value)){this.value=[];this.clear()}// Lets us keep track of how many items we stamped so we can clear leftover
// items from a previous render
var itemParts=this.value,partIndex=0,itemPart,_iteratorNormalCompletion5=!0,_didIteratorError5=!1,_iteratorError5=void 0;try{for(var _iterator5=value[Symbol.iterator](),_step5,item;!(_iteratorNormalCompletion5=(_step5=_iterator5.next()).done);_iteratorNormalCompletion5=!0){item=_step5.value;// Try to reuse an existing part
itemPart=itemParts[partIndex];// If no existing part, create a new one
if(itemPart===void 0){itemPart=new NodePart(this.options);itemParts.push(itemPart);if(0===partIndex){itemPart.appendIntoPart(this)}else{itemPart.insertAfterPart(itemParts[partIndex-1])}}itemPart.setValue(item);itemPart.commit();partIndex++}}catch(err){_didIteratorError5=!0;_iteratorError5=err}finally{try{if(!_iteratorNormalCompletion5&&null!=_iterator5.return){_iterator5.return()}}finally{if(_didIteratorError5){throw _iteratorError5}}}if(partIndex<itemParts.length){// Truncate the parts array so _value reflects the current state
itemParts.length=partIndex;this.clear(itemPart&&itemPart.endNode)}}},{key:"clear",value:function clear(){var startNode=0<arguments.length&&arguments[0]!==void 0?arguments[0]:this.startNode;removeNodes(this.startNode.parentNode,startNode.nextSibling,this.endNode)}}]);return NodePart}();/**
   * Implements a boolean attribute, roughly as defined in the HTML
   * specification.
   *
   * If the value is truthy, then the attribute is present with a value of
   * ''. If the value is falsey, the attribute is removed.
   */_exports.NodePart$1=_exports.NodePart=NodePart;var BooleanAttributePart=/*#__PURE__*/function(){function BooleanAttributePart(element,name,strings){babelHelpers.classCallCheck(this,BooleanAttributePart);this.value=void 0;this._pendingValue=void 0;if(2!==strings.length||""!==strings[0]||""!==strings[1]){throw new Error("Boolean attributes can only contain a single expression")}this.element=element;this.name=name;this.strings=strings}babelHelpers.createClass(BooleanAttributePart,[{key:"setValue",value:function setValue(value){this._pendingValue=value}},{key:"commit",value:function commit(){while(isDirective(this._pendingValue)){var _directive3=this._pendingValue;this._pendingValue=noChange;_directive3(this)}if(this._pendingValue===noChange){return}var value=!!this._pendingValue;if(this.value!==value){if(value){this.element.setAttribute(this.name,"")}else{this.element.removeAttribute(this.name)}}this.value=value;this._pendingValue=noChange}}]);return BooleanAttributePart}();/**
   * Sets attribute values for PropertyParts, so that the value is only set once
   * even if there are multiple parts for a property.
   *
   * If an expression controls the whole property value, then the value is simply
   * assigned to the property under control. If there are string literals or
   * multiple expressions, then the strings are expressions are interpolated into
   * a string first.
   */_exports.BooleanAttributePart$1=_exports.BooleanAttributePart=BooleanAttributePart;var PropertyCommitter=/*#__PURE__*/function(_AttributeCommitter){babelHelpers.inherits(PropertyCommitter,_AttributeCommitter);function PropertyCommitter(element,name,strings){var _this10;babelHelpers.classCallCheck(this,PropertyCommitter);_this10=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(PropertyCommitter).call(this,element,name,strings));_this10.single=2===strings.length&&""===strings[0]&&""===strings[1];return _this10}babelHelpers.createClass(PropertyCommitter,[{key:"_createPart",value:function _createPart(){return new PropertyPart(this)}},{key:"_getValue",value:function _getValue(){if(this.single){return this.parts[0].value}return babelHelpers.get(babelHelpers.getPrototypeOf(PropertyCommitter.prototype),"_getValue",this).call(this)}},{key:"commit",value:function commit(){if(this.dirty){this.dirty=!1;// tslint:disable-next-line:no-any
this.element[this.name]=this._getValue()}}}]);return PropertyCommitter}(AttributeCommitter);_exports.PropertyCommitter$1=_exports.PropertyCommitter=PropertyCommitter;var PropertyPart=/*#__PURE__*/function(_AttributePart){babelHelpers.inherits(PropertyPart,_AttributePart);function PropertyPart(){babelHelpers.classCallCheck(this,PropertyPart);return babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(PropertyPart).apply(this,arguments))}return PropertyPart}(AttributePart);// Detect event listener options support. If the `capture` property is read
// from the options object, then options are supported. If not, then the thrid
// argument to add/removeEventListener is interpreted as the boolean capture
// value so we should only pass the `capture` property.
_exports.PropertyPart$1=_exports.PropertyPart=PropertyPart;var eventOptionsSupported=!1;try{var options={get capture(){eventOptionsSupported=!0;return!1}};// tslint:disable-next-line:no-any
window.addEventListener("test",options,options);// tslint:disable-next-line:no-any
window.removeEventListener("test",options,options)}catch(_e){}var EventPart=/*#__PURE__*/function(){function EventPart(element,eventName,eventContext){var _this11=this;babelHelpers.classCallCheck(this,EventPart);this.value=void 0;this._pendingValue=void 0;this.element=element;this.eventName=eventName;this.eventContext=eventContext;this._boundHandleEvent=function(e){return _this11.handleEvent(e)}}babelHelpers.createClass(EventPart,[{key:"setValue",value:function setValue(value){this._pendingValue=value}},{key:"commit",value:function commit(){while(isDirective(this._pendingValue)){var _directive4=this._pendingValue;this._pendingValue=noChange;_directive4(this)}if(this._pendingValue===noChange){return}var newListener=this._pendingValue,oldListener=this.value,shouldRemoveListener=null==newListener||null!=oldListener&&(newListener.capture!==oldListener.capture||newListener.once!==oldListener.once||newListener.passive!==oldListener.passive),shouldAddListener=null!=newListener&&(null==oldListener||shouldRemoveListener);if(shouldRemoveListener){this.element.removeEventListener(this.eventName,this._boundHandleEvent,this._options)}if(shouldAddListener){this._options=getOptions(newListener);this.element.addEventListener(this.eventName,this._boundHandleEvent,this._options)}this.value=newListener;this._pendingValue=noChange}},{key:"handleEvent",value:function handleEvent(event){if("function"===typeof this.value){this.value.call(this.eventContext||this.element,event)}else{this.value.handleEvent(event)}}}]);return EventPart}();// We copy options because of the inconsistent behavior of browsers when reading
// the third argument of add/removeEventListener. IE11 doesn't support options
// at all. Chrome 41 only reads `capture` if the argument is an object.
_exports.EventPart$1=_exports.EventPart=EventPart;var getOptions=function getOptions(o){return o&&(eventOptionsSupported?{capture:o.capture,passive:o.passive,once:o.once}:o.capture)},parts={isPrimitive:isPrimitive,AttributeCommitter:AttributeCommitter,AttributePart:AttributePart,NodePart:NodePart,BooleanAttributePart:BooleanAttributePart,PropertyCommitter:PropertyCommitter,PropertyPart:PropertyPart,EventPart:EventPart};_exports.$parts=parts;var DefaultTemplateProcessor=/*#__PURE__*/function(){function DefaultTemplateProcessor(){babelHelpers.classCallCheck(this,DefaultTemplateProcessor)}babelHelpers.createClass(DefaultTemplateProcessor,[{key:"handleAttributeExpressions",/**
   * Create parts for an attribute-position binding, given the event, attribute
   * name, and string literals.
   *
   * @param element The element containing the binding
   * @param name  The attribute name
   * @param strings The string literals. There are always at least two strings,
   *   event for fully-controlled bindings with a single expression.
   */value:function handleAttributeExpressions(element,name,strings,options){var prefix=name[0];if("."===prefix){var _comitter=new PropertyCommitter(element,name.slice(1),strings);return _comitter.parts}if("@"===prefix){return[new EventPart(element,name.slice(1),options.eventContext)]}if("?"===prefix){return[new BooleanAttributePart(element,name.slice(1),strings)]}var comitter=new AttributeCommitter(element,name,strings);return comitter.parts}/**
     * Create parts for a text-position binding.
     * @param templateFactory
     */},{key:"handleTextExpression",value:function handleTextExpression(options){return new NodePart(options)}}]);return DefaultTemplateProcessor}();_exports.DefaultTemplateProcessor$1=_exports.DefaultTemplateProcessor=DefaultTemplateProcessor;var defaultTemplateProcessor=new DefaultTemplateProcessor;_exports.defaultTemplateProcessor$1=_exports.defaultTemplateProcessor=defaultTemplateProcessor;var defaultTemplateProcessor$1={DefaultTemplateProcessor:DefaultTemplateProcessor,defaultTemplateProcessor:defaultTemplateProcessor};_exports.$defaultTemplateProcessor=defaultTemplateProcessor$1;function templateFactory(result){var templateCache=templateCaches.get(result.type);if(templateCache===void 0){templateCache={stringsArray:new WeakMap,keyString:new Map};templateCaches.set(result.type,templateCache)}var template=templateCache.stringsArray.get(result.strings);if(template!==void 0){return template}// If the TemplateStringsArray is new, generate a key from the strings
// This key is shared between all templates with identical content
var key=result.strings.join(marker);// Check if we already have a Template for this key
template=templateCache.keyString.get(key);if(template===void 0){// If we have not seen this key before, create a new Template
template=new Template(result,result.getTemplateElement());// Cache the Template for this key
templateCache.keyString.set(key,template)}// Cache all future queries for this TemplateStringsArray
templateCache.stringsArray.set(result.strings,template);return template}var templateCaches=new Map;_exports.templateCaches$1=_exports.templateCaches=templateCaches;var templateFactory$1={templateFactory:templateFactory,templateCaches:templateCaches};_exports.$templateFactory=templateFactory$1;var parts$1=new WeakMap;/**
                                     * Renders a template to a container.
                                     *
                                     * To update a container with new values, reevaluate the template literal and
                                     * call `render` with the new result.
                                     *
                                     * @param result a TemplateResult created by evaluating a template tag like
                                     *     `html` or `svg`.
                                     * @param container A DOM parent to render to. The entire contents are either
                                     *     replaced, or efficiently updated if the same result type was previous
                                     *     rendered there.
                                     * @param options RenderOptions for the entire render tree rendered to this
                                     *     container. Render options must *not* change between renders to the same
                                     *     container, as those changes will not effect previously rendered DOM.
                                     */_exports.parts$1=_exports.parts=parts$1;var render=function render(result,container,options){var part=parts$1.get(container);if(part===void 0){removeNodes(container,container.firstChild);parts$1.set(container,part=new NodePart(Object.assign({templateFactory:templateFactory},options)));part.appendInto(container)}part.setValue(result);part.commit()};_exports.render$2=_exports.render=render;var render$1={parts:parts$1,render:render};// This line will be used in regexes to search for lit-html usage.
// TODO(justinfagnani): inject version number at build time
_exports.$render=render$1;(window.litHtmlVersions||(window.litHtmlVersions=[])).push("1.0.0");/**
                                                                                * Interprets a template literal as an HTML template that can efficiently
                                                                                * render to and update a container.
                                                                                */var html=function html(strings){for(var _len2=arguments.length,values=Array(1<_len2?_len2-1:0),_key2=1;_key2<_len2;_key2++){values[_key2-1]=arguments[_key2]}return new TemplateResult(strings,values,"html",defaultTemplateProcessor)};/**
                                                                                                                    * Interprets a template literal as an SVG template that can efficiently
                                                                                                                    * render to and update a container.
                                                                                                                    */_exports.html$2=_exports.html$1=_exports.html=html;var svg=function svg(strings){for(var _len3=arguments.length,values=Array(1<_len3?_len3-1:0),_key3=1;_key3<_len3;_key3++){values[_key3-1]=arguments[_key3]}return new SVGTemplateResult(strings,values,"svg",defaultTemplateProcessor)};_exports.svg$2=_exports.svg$1=_exports.svg=svg;var litHtml={html:html,svg:svg,DefaultTemplateProcessor:DefaultTemplateProcessor,defaultTemplateProcessor:defaultTemplateProcessor,directive:directive,isDirective:isDirective,removeNodes:removeNodes,reparentNodes:reparentNodes,noChange:noChange,nothing:nothing,AttributeCommitter:AttributeCommitter,AttributePart:AttributePart,BooleanAttributePart:BooleanAttributePart,EventPart:EventPart,isPrimitive:isPrimitive,NodePart:NodePart,PropertyCommitter:PropertyCommitter,PropertyPart:PropertyPart,parts:parts$1,render:render,templateCaches:templateCaches,templateFactory:templateFactory,TemplateInstance:TemplateInstance,SVGTemplateResult:SVGTemplateResult,TemplateResult:TemplateResult,createMarker:createMarker,isTemplatePartActive:isTemplatePartActive,Template:Template};_exports.$litHtml=litHtml;var walkerNodeFilter=133/* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */;/**
                                                                            * Removes the list of nodes from a Template safely. In addition to removing
                                                                            * nodes from the Template, the Template part indices are updated to match
                                                                            * the mutated Template DOM.
                                                                            *
                                                                            * As the template is walked the removal state is tracked and
                                                                            * part indices are adjusted as needed.
                                                                            *
                                                                            * div
                                                                            *   div#1 (remove) <-- start removing (removing node is div#1)
                                                                            *     div
                                                                            *       div#2 (remove)  <-- continue removing (removing node is still div#1)
                                                                            *         div
                                                                            * div <-- stop removing since previous sibling is the removing node (div#1,
                                                                            * removed 4 nodes)
                                                                            */function removeNodesFromTemplate(template,nodesToRemove){var content=template.element.content,parts=template.parts,walker=document.createTreeWalker(content,walkerNodeFilter,null,!1),partIndex=nextActiveIndexInTemplateParts(parts),part=parts[partIndex],nodeIndex=-1,removeCount=0,nodesToRemoveInTemplate=[],currentRemovingNode=null;while(walker.nextNode()){nodeIndex++;var node=walker.currentNode;// End removal if stepped past the removing node
if(node.previousSibling===currentRemovingNode){currentRemovingNode=null}// A node to remove was found in the template
if(nodesToRemove.has(node)){nodesToRemoveInTemplate.push(node);// Track node we're removing
if(null===currentRemovingNode){currentRemovingNode=node}}// When removing, increment count by which to adjust subsequent part indices
if(null!==currentRemovingNode){removeCount++}while(part!==void 0&&part.index===nodeIndex){// If part is in a removed node deactivate it by setting index to -1 or
// adjust the index as needed.
part.index=null!==currentRemovingNode?-1:part.index-removeCount;// go to the next active part.
partIndex=nextActiveIndexInTemplateParts(parts,partIndex);part=parts[partIndex]}}nodesToRemoveInTemplate.forEach(function(n){return n.parentNode.removeChild(n)})}var countNodes=function countNodes(node){var count=11===node.nodeType/* Node.DOCUMENT_FRAGMENT_NODE */?0:1,walker=document.createTreeWalker(node,walkerNodeFilter,null,!1);while(walker.nextNode()){count++}return count},nextActiveIndexInTemplateParts=function nextActiveIndexInTemplateParts(parts){for(var startIndex=1<arguments.length&&arguments[1]!==void 0?arguments[1]:-1,i=startIndex+1,_part6;i<parts.length;i++){_part6=parts[i];if(isTemplatePartActive(_part6)){return i}}return-1};/**
    * Inserts the given node into the Template, optionally before the given
    * refNode. In addition to inserting the node into the Template, the Template
    * part indices are updated to match the mutated Template DOM.
    */function insertNodeIntoTemplate(template,node){var refNode=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null,content=template.element.content,parts=template.parts;// If there's no refNode, then put node at end of template.
// No part indices need to be shifted in this case.
if(null===refNode||refNode===void 0){content.appendChild(node);return}var walker=document.createTreeWalker(content,walkerNodeFilter,null,!1),partIndex=nextActiveIndexInTemplateParts(parts),insertCount=0,walkerIndex=-1;while(walker.nextNode()){walkerIndex++;var walkerNode=walker.currentNode;if(walkerNode===refNode){insertCount=countNodes(node);refNode.parentNode.insertBefore(node,refNode)}while(-1!==partIndex&&parts[partIndex].index===walkerIndex){// If we've inserted the node, simply adjust all subsequent parts
if(0<insertCount){while(-1!==partIndex){parts[partIndex].index+=insertCount;partIndex=nextActiveIndexInTemplateParts(parts,partIndex)}return}partIndex=nextActiveIndexInTemplateParts(parts,partIndex)}}}var modifyTemplate={removeNodesFromTemplate:removeNodesFromTemplate,insertNodeIntoTemplate:insertNodeIntoTemplate};_exports.$modifyTemplate=modifyTemplate;var getTemplateCacheKey=function getTemplateCacheKey(type,scopeName){return"".concat(type,"--").concat(scopeName)},compatibleShadyCSSVersion=!0;if("undefined"===typeof window.ShadyCSS){compatibleShadyCSSVersion=!1}else if("undefined"===typeof window.ShadyCSS.prepareTemplateDom){console.warn("Incompatible ShadyCSS version detected."+"Please update to at least @webcomponents/webcomponentsjs@2.0.2 and"+"@webcomponents/shadycss@1.3.1.");compatibleShadyCSSVersion=!1}/**
   * Template factory which scopes template DOM using ShadyCSS.
   * @param scopeName {string}
   */var shadyTemplateFactory=function shadyTemplateFactory(scopeName){return function(result){var cacheKey=getTemplateCacheKey(result.type,scopeName),templateCache=templateCaches.get(cacheKey);if(templateCache===void 0){templateCache={stringsArray:new WeakMap,keyString:new Map};templateCaches.set(cacheKey,templateCache)}var template=templateCache.stringsArray.get(result.strings);if(template!==void 0){return template}var key=result.strings.join(marker);template=templateCache.keyString.get(key);if(template===void 0){var element=result.getTemplateElement();if(compatibleShadyCSSVersion){window.ShadyCSS.prepareTemplateDom(element,scopeName)}template=new Template(result,element);templateCache.keyString.set(key,template)}templateCache.stringsArray.set(result.strings,template);return template}},TEMPLATE_TYPES=["html","svg"],removeStylesFromLitTemplates=function removeStylesFromLitTemplates(scopeName){TEMPLATE_TYPES.forEach(function(type){var templates=templateCaches.get(getTemplateCacheKey(type,scopeName));if(templates!==void 0){templates.keyString.forEach(function(template){var content=template.element.content,styles=new Set;// IE 11 doesn't support the iterable param Set constructor
Array.from(content.querySelectorAll("style")).forEach(function(s){styles.add(s)});removeNodesFromTemplate(template,styles)})}})},shadyRenderSet=new Set,prepareTemplateStyles=function prepareTemplateStyles(renderedDOM,template,scopeName){shadyRenderSet.add(scopeName);// Move styles out of rendered DOM and store.
var styles=renderedDOM.querySelectorAll("style");// If there are no styles, skip unnecessary work
if(0===styles.length){// Ensure prepareTemplateStyles is called to support adding
// styles via `prepareAdoptedCssText` since that requires that
// `prepareTemplateStyles` is called.
window.ShadyCSS.prepareTemplateStyles(template.element,scopeName);return}// Collect styles into a single style. This helps us make sure ShadyCSS
// manipulations will not prevent us from being able to fix up template
// part indices.
// NOTE: collecting styles is inefficient for browsers but ShadyCSS
// currently does this anyway. When it does not, this should be changed.
for(var condensedStyle=document.createElement("style"),i=0,style;i<styles.length;i++){style=styles[i];style.parentNode.removeChild(style);condensedStyle.textContent+=style.textContent}// Remove styles from nested templates in this scope.
removeStylesFromLitTemplates(scopeName);// And then put the condensed style into the "root" template passed in as
// `template`.
insertNodeIntoTemplate(template,condensedStyle,template.element.content.firstChild);// Note, it's important that ShadyCSS gets the template that `lit-html`
// will actually render so that it can update the style inside when
// needed (e.g. @apply native Shadow DOM case).
window.ShadyCSS.prepareTemplateStyles(template.element,scopeName);if(window.ShadyCSS.nativeShadow){// When in native Shadow DOM, re-add styling to rendered content using
// the style ShadyCSS produced.
var _style=template.element.content.querySelector("style");renderedDOM.insertBefore(_style.cloneNode(!0),renderedDOM.firstChild)}else{// When not in native Shadow DOM, at this point ShadyCSS will have
// removed the style from the lit template and parts will be broken as a
// result. To fix this, we put back the style node ShadyCSS removed
// and then tell lit to remove that node from the template.
// NOTE, ShadyCSS creates its own style so we can safely add/remove
// `condensedStyle` here.
template.element.content.insertBefore(condensedStyle,template.element.content.firstChild);var removes=new Set([condensedStyle]);removeNodesFromTemplate(template,removes)}},render$2=function render$2(result,container,options){var scopeName=options.scopeName,hasRendered=parts$1.has(container),needsScoping=babelHelpers.instanceof(container,ShadowRoot)&&compatibleShadyCSSVersion&&babelHelpers.instanceof(result,TemplateResult),firstScopeRender=needsScoping&&!shadyRenderSet.has(scopeName),renderContainer=firstScopeRender?document.createDocumentFragment():container;render(result,renderContainer,Object.assign({templateFactory:shadyTemplateFactory(scopeName)},options));// When performing first scope render,
// (1) We've rendered into a fragment so that there's a chance to
// `prepareTemplateStyles` before sub-elements hit the DOM
// (which might cause them to render based on a common pattern of
// rendering in a custom element's `connectedCallback`);
// (2) Scope the template with ShadyCSS one time only for this scope.
// (3) Render the fragment into the container and make sure the
// container knows its `part` is the one we just rendered. This ensures
// DOM will be re-used on subsequent renders.
if(firstScopeRender){var _part7=parts$1.get(renderContainer);parts$1.delete(renderContainer);if(babelHelpers.instanceof(_part7.value,TemplateInstance)){prepareTemplateStyles(renderContainer,_part7.value.template,scopeName)}removeNodes(container,container.firstChild);container.appendChild(renderContainer);parts$1.set(container,_part7)}// After elements have hit the DOM, update styling if this is the
// initial render to this container.
// This is needed whenever dynamic changes are made so it would be
// safest to do every render; however, this would regress performance
// so we leave it up to the user to call `ShadyCSSS.styleElement`
// for dynamic changes.
if(!hasRendered&&needsScoping){window.ShadyCSS.styleElement(container.host)}};_exports.render$1=render$2;var shadyRender={render:render$2,html:html,svg:svg,TemplateResult:TemplateResult};// IMPORTANT: do not change the property name or the assignment expression.
// This line will be used in regexes to search for LitElement usage.
// TODO(justinfagnani): inject version number at build time
_exports.$shadyRender=shadyRender;(window.litElementVersions||(window.litElementVersions=[])).push("2.0.1");/**
                                                                                      * Minimal implementation of Array.prototype.flat
                                                                                      * @param arr the array to flatten
                                                                                      * @param result the accumlated result
                                                                                      */function arrayFlat(styles){for(var result=1<arguments.length&&arguments[1]!==void 0?arguments[1]:[],i=0,length=styles.length,value;i<length;i++){value=styles[i];if(Array.isArray(value)){arrayFlat(value,result)}else{result.push(value)}}return result}/** Deeply flattens styles array. Uses native flat if available. */var flattenStyles=function flattenStyles(styles){return styles.flat?styles.flat(1/0):arrayFlat(styles)},LitElement=/*#__PURE__*/function(_UpdatingElement){babelHelpers.inherits(LitElement,_UpdatingElement);function LitElement(){babelHelpers.classCallCheck(this,LitElement);return babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(LitElement).apply(this,arguments))}babelHelpers.createClass(LitElement,[{key:"initialize",/**
     * Performs element initialization. By default this calls `createRenderRoot`
     * to create the element `renderRoot` node and captures any pre-set values for
     * registered properties.
     */value:function initialize(){babelHelpers.get(babelHelpers.getPrototypeOf(LitElement.prototype),"initialize",this).call(this);this.renderRoot=this.createRenderRoot();// Note, if renderRoot is not a shadowRoot, styles would/could apply to the
// element's getRootNode(). While this could be done, we're choosing not to
// support this now since it would require different logic around de-duping.
if(window.ShadowRoot&&babelHelpers.instanceof(this.renderRoot,window.ShadowRoot)){this.adoptStyles()}}/**
     * Returns the node into which the element should render and by default
     * creates and returns an open shadowRoot. Implement to customize where the
     * element's DOM is rendered. For example, to render into the element's
     * childNodes, return `this`.
     * @returns {Element|DocumentFragment} Returns a node into which to render.
     */},{key:"createRenderRoot",value:function createRenderRoot(){return this.attachShadow({mode:"open"})}/**
     * Applies styling to the element shadowRoot using the `static get styles`
     * property. Styling will apply using `shadowRoot.adoptedStyleSheets` where
     * available and will fallback otherwise. When Shadow DOM is polyfilled,
     * ShadyCSS scopes styles and adds them to the document. When Shadow DOM
     * is available but `adoptedStyleSheets` is not, styles are appended to the
     * end of the `shadowRoot` to [mimic spec
     * behavior](https://wicg.github.io/construct-stylesheets/#using-constructed-stylesheets).
     */},{key:"adoptStyles",value:function adoptStyles(){var styles=this.constructor._styles;if(0===styles.length){return}// There are three separate cases here based on Shadow DOM support.
// (1) shadowRoot polyfilled: use ShadyCSS
// (2) shadowRoot.adoptedStyleSheets available: use it.
// (3) shadowRoot.adoptedStyleSheets polyfilled: append styles after
// rendering
if(window.ShadyCSS!==void 0&&!window.ShadyCSS.nativeShadow){window.ShadyCSS.ScopingShim.prepareAdoptedCssText(styles.map(function(s){return s.cssText}),this.localName)}else if(supportsAdoptingStyleSheets){this.renderRoot.adoptedStyleSheets=styles.map(function(s){return s.styleSheet})}else{// This must be done after rendering so the actual style insertion is done
// in `update`.
this._needsShimAdoptedStyleSheets=!0}}},{key:"connectedCallback",value:function connectedCallback(){babelHelpers.get(babelHelpers.getPrototypeOf(LitElement.prototype),"connectedCallback",this).call(this);// Note, first update/render handles styleElement so we only call this if
// connected after first update.
if(this.hasUpdated&&window.ShadyCSS!==void 0){window.ShadyCSS.styleElement(this)}}/**
     * Updates the element. This method reflects property values to attributes
     * and calls `render` to render DOM via lit-html. Setting properties inside
     * this method will *not* trigger another update.
     * * @param _changedProperties Map of changed properties with old values
     */},{key:"update",value:function update(changedProperties){var _this12=this;babelHelpers.get(babelHelpers.getPrototypeOf(LitElement.prototype),"update",this).call(this,changedProperties);var templateResult=this.render();if(babelHelpers.instanceof(templateResult,TemplateResult)){this.constructor.render(templateResult,this.renderRoot,{scopeName:this.localName,eventContext:this})}// When native Shadow DOM is used but adoptedStyles are not supported,
// insert styling after rendering to ensure adoptedStyles have highest
// priority.
if(this._needsShimAdoptedStyleSheets){this._needsShimAdoptedStyleSheets=!1;this.constructor._styles.forEach(function(s){var style=document.createElement("style");style.textContent=s.cssText;_this12.renderRoot.appendChild(style)})}}/**
     * Invoked on each update to perform rendering tasks. This method must return
     * a lit-html TemplateResult. Setting properties inside this method will *not*
     * trigger the element to update.
     */},{key:"render",value:function render(){}}],[{key:"finalize",/** @nocollapse */value:function finalize(){babelHelpers.get(babelHelpers.getPrototypeOf(LitElement),"finalize",this).call(this);// Prepare styling that is stamped at first render time. Styling
// is built from user provided `styles` or is inherited from the superclass.
this._styles=this.hasOwnProperty(JSCompiler_renameProperty("styles",this))?this._getUniqueStyles():this._styles||[]}/** @nocollapse */},{key:"_getUniqueStyles",value:function _getUniqueStyles(){// Take care not to call `this.styles` multiple times since this generates
// new CSSResults each time.
// TODO(sorvell): Since we do not cache CSSResults by input, any
// shared styles will generate new stylesheet objects, which is wasteful.
// This should be addressed when a browser ships constructable
// stylesheets.
var userStyles=this.styles,styles=[];if(Array.isArray(userStyles)){var flatStyles=flattenStyles(userStyles),styleSet=flatStyles.reduceRight(function(set,s){set.add(s);// on IE set.add does not return the set.
return set},new Set);// As a performance optimization to avoid duplicated styling that can
// occur especially when composing via subclassing, de-duplicate styles
// preserving the last item in the list. The last item is kept to
// try to preserve cascade order with the assumption that it's most
// important that last added styles override previous styles.
// Array.from does not work on Set in IE
styleSet.forEach(function(v){return styles.unshift(v)})}else if(userStyles){styles.push(userStyles)}return styles}}]);return LitElement}(UpdatingElement);_exports.LitElement=LitElement;/**
   * Ensure this class is marked as `finalized` as an optimization ensuring
   * it will not needlessly try to `finalize`.
   */LitElement.finalized=!0;/**
                              * Render method used to render the lit-html TemplateResult to the element's
                              * DOM.
                              * @param {TemplateResult} Template to render.
                              * @param {Element|DocumentFragment} Node into which to render.
                              * @param {String} Element name.
                              * @nocollapse
                              */LitElement.render=render$2;var litElement={LitElement:LitElement,defaultConverter:defaultConverter,notEqual:notEqual,UpdatingElement:UpdatingElement,customElement:customElement,property:property,query:query,queryAll:queryAll,eventOptions:eventOptions,html:html,svg:svg,TemplateResult:TemplateResult,SVGTemplateResult:SVGTemplateResult,supportsAdoptingStyleSheets:supportsAdoptingStyleSheets,CSSResult:CSSResult,unsafeCSS:unsafeCSS,css:css};// unsafeHTML directive, and the DocumentFragment that was last set as a value.
// The DocumentFragment is used as a unique key to check if the last value
// rendered to the part was with unsafeHTML. If not, we'll always re-render the
// value passed to unsafeHTML.
_exports.$litElement=litElement;var previousValues=new WeakMap,unsafeHTML=directive(function(value){return function(part){if(!babelHelpers.instanceof(part,NodePart)){throw new Error("unsafeHTML can only be used in text bindings")}var previousValue=previousValues.get(part);if(previousValue!==void 0&&isPrimitive(value)&&value===previousValue.value&&part.value===previousValue.fragment){return}var template=document.createElement("template");template.innerHTML=value;// innerHTML casts to string internally
var fragment=document.importNode(template.content,!0);part.setValue(fragment);previousValues.set(part,{value:value,fragment:fragment})}});/**
                                       * Renders the result as HTML, rather than text.
                                       *
                                       * Note, this is unsafe to use with any user-provided input that hasn't been
                                       * sanitized or escaped, as it may lead to cross-site-scripting
                                       * vulnerabilities.
                                       */_exports.unsafeHTML=unsafeHTML;var unsafeHtml={unsafeHTML:unsafeHTML};_exports.$unsafeHtml=unsafeHtml;var MpAccordion=/*#__PURE__*/function(_LitElement){babelHelpers.inherits(MpAccordion,_LitElement);babelHelpers.createClass(MpAccordion,null,[{key:"properties",get:function get(){return{open:{type:Boolean}}}},{key:"styles",get:function get(){return css(_templateObject_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MpAccordion(){var _this13;babelHelpers.classCallCheck(this,MpAccordion);_this13=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MpAccordion).call(this));_this13.open=!1;return _this13}babelHelpers.createClass(MpAccordion,[{key:"render",value:function render(){var _this14=this;return html(_templateObject2_2b46c4105c5e11e9a640aba88724ddc3(),this.open?" active":"",function(e){return _this14.handleClick(e)})}},{key:"handleClick",value:function handleClick(e){this.open=!this.open}}]);return MpAccordion}(LitElement);window.customElements.define("mp-accordion",MpAccordion);var MapproxyConfig=/*#__PURE__*/function(_LitElement2){babelHelpers.inherits(MapproxyConfig,_LitElement2);babelHelpers.createClass(MapproxyConfig,null,[{key:"properties",get:function get(){return{config:{type:Object},localConfig:{type:Object},open:{type:Boolean}}}},{key:"styles",get:function get(){return css(_templateObject3_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyConfig(){var _this15;babelHelpers.classCallCheck(this,MapproxyConfig);_this15=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyConfig).call(this));_this15.config={};_this15.localConfig=window.localStorage.config?JSON.parse(window.localStorage.config):{};_this15.open=!1;return _this15}babelHelpers.createClass(MapproxyConfig,[{key:"shouldUpdate",value:function shouldUpdate(changedProperties){if(changedProperties.has("config")){if(!window.localStorage.config){window.localStorage.config=JSON.stringify(this.config);this.localConfig=JSON.parse(window.localStorage.config)}}return!0}},{key:"render",value:function render(){var _this16=this;return html(_templateObject4_2b46c4105c5e11e9a640aba88724ddc3(),function(e){return _this16.toggleOpen(e)},this.configForm())}},{key:"configForm",value:function configForm(){var _this17=this;if(!this.open){return html(_templateObject5_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject6_2b46c4105c5e11e9a640aba88724ddc3(),this.localConfig.mapproxydir,this.localConfig.metadata.online_resource,this.localConfig.metadata.access_constraints,this.localConfig.metadata.fees,this.localConfig.metadata.contact.person,this.localConfig.metadata.contact.position,this.localConfig.metadata.contact.organization,this.localConfig.metadata.contact.city,this.localConfig.metadata.contact.postcode,this.localConfig.metadata.contact.country,this.localConfig.metadata.contact.email,function(e){return _this17.saveConfig()},function(e){return _this17.resetConfig()})}},{key:"toggleOpen",value:function toggleOpen(e){this.open=!this.open}},{key:"emitLocalConfigUpdate",value:function emitLocalConfigUpdate(){this.dispatchEvent(new CustomEvent("localConfigUpdate",{bubbles:!0,composed:!0}))}},{key:"saveConfig",value:function saveConfig(){this.localConfig.mapproxydir=this.shadowRoot.querySelector("#mapproxydir").value;this.localConfig.metadata.online_resource=this.shadowRoot.querySelector("#online_resource").value;this.localConfig.metadata.access_constraints=this.shadowRoot.querySelector("#access_constraints").value;this.localConfig.metadata.fees=this.shadowRoot.querySelector("#fees").value;this.localConfig.metadata.contact.person=this.shadowRoot.querySelector("#person").value;this.localConfig.metadata.contact.position=this.shadowRoot.querySelector("#position").value;this.localConfig.metadata.contact.organization=this.shadowRoot.querySelector("#organization").value;this.localConfig.metadata.contact.city=this.shadowRoot.querySelector("#city").value;this.localConfig.metadata.contact.postcode=this.shadowRoot.querySelector("#postcode").value;this.localConfig.metadata.contact.country=this.shadowRoot.querySelector("#country").value;this.localConfig.metadata.contact.email=this.shadowRoot.querySelector("#email").value;window.localStorage.config=JSON.stringify(this.localConfig);this.emitLocalConfigUpdate()}},{key:"resetConfig",value:function resetConfig(){window.localStorage.config=JSON.stringify(this.config);this.localConfig=JSON.parse(window.localStorage.config);this.emitLocalConfigUpdate()}}]);return MapproxyConfig}(LitElement);window.customElements.define("mapproxy-config",MapproxyConfig);function pathJoin(parts,sep){var separator=sep||"/";parts=parts.map(function(part,index){if(index){part=part.replace(new RegExp("^"+separator),"")}if(index!==parts.length-1){part=part.replace(new RegExp(separator+"$"),"")}return part});return parts.join(separator)}var util={pathJoin:pathJoin};_exports.$util=util;function quote(str){return str.replace(/'/g,"''").replace(/[\r\n]+/g,"\\n")}function escape(name){return quote(name.replace(/ /g,"_").replace(/:/g,"_"))}function layerSRS(layer){var srs;if(layer.SRS&&layer.SRS.length){srs=layer.SRS.find(function(srs){return"EPSG:3857"===srs});if(!srs){// find first projected SRS
srs=layer.SRS.find(function(srs){return"CRS:84"!==srs&&"EPSG:4326"!==srs})}if(!srs){srs=layer.SRS.find(function(srs){return"EPSG:4326"===srs})}if(!srs){srs=layer.SRS.length?layer.SRS[0]:"EPSG:3857"}}return srs}/**
  * @polymer
  * @extends HTMLElement
  */var MapproxyGetCaps=/*#__PURE__*/function(_LitElement3){babelHelpers.inherits(MapproxyGetCaps,_LitElement3);babelHelpers.createClass(MapproxyGetCaps,null,[{key:"properties",get:function get(){return{open:{type:Boolean},capabilities:{type:Object},errorMessage:{type:String},createButtonDisabled:{type:Boolean},list:{type:Array},createResult:{type:String},getcapabilitiesResult:{type:String}}}},{key:"styles",get:function get(){return css(_templateObject7_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyGetCaps(){var _this18;babelHelpers.classCallCheck(this,MapproxyGetCaps);_this18=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyGetCaps).call(this));_this18.open=!1;_this18.capabilities={};_this18.errorMessage="";_this18.getcapabilitiesurl="";_this18.selectedLayers=new Set;_this18.createButtonDisabled=!0;_this18.list=[];_this18.createResult="";_this18.getcapabilitiesResult="";return _this18}babelHelpers.createClass(MapproxyGetCaps,[{key:"shouldUpdate",value:function shouldUpdate(changedProperties){if(changedProperties.has("list")){this.updateCreateButton()}return!0}},{key:"render",value:function render(){var _this19=this;return html(_templateObject8_2b46c4105c5e11e9a640aba88724ddc3(),function(e){return _this19.toggleOpen()},this.renderGetCapabilitiesForm(),this.renderErrorMessage(),this.renderCapabilities())}},{key:"toggleOpen",value:function toggleOpen(){this.open=!this.open}},{key:"renderGetCapabilitiesForm",value:function renderGetCapabilitiesForm(){var _this20=this;if(!this.open){return html(_templateObject9_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject10_2b46c4105c5e11e9a640aba88724ddc3(),this.getcapabilitiesurl,function(e){return _this20.fetchCapabilities(e)},this.getcapabilitiesResult)}},{key:"renderErrorMessage",value:function renderErrorMessage(){if(!this.errorMessage){return html(_templateObject11_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject12_2b46c4105c5e11e9a640aba88724ddc3(),this.errorMessage)}},{key:"renderCapabilities",value:function renderCapabilities(){var _this21=this;if(!this.open){return html(_templateObject13_2b46c4105c5e11e9a640aba88724ddc3())}if(!this.capabilities.Capability){return html(_templateObject14_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject15_2b46c4105c5e11e9a640aba88724ddc3(),this.capabilities.Service.Title,this.capabilities.Service.Abstract,this.capabilities.Service.AccessConstraints,this.capabilities.Service.Fees?this.capabilities.Service.Fees:"",((this.capabilities.Service.ContactInformation||"").ContactPersonPrimary||"").ContactPerson||"",((this.capabilities.Service.ContactInformation||"").ContactPersonPrimary||"").ContactOrganization||"",((this.capabilities.Service.ContactInformation||"").ContactPersonPrimary||"").ContactVoiceTelephone||"",((this.capabilities.Service.ContactInformation||"").ContactPersonPrimary||"").ContactElectronicMailAddress||"",function(e){return _this21.toggleAllChecks(e)},this.renderLayers(this.capabilities.Capability.Layer),function(e){return _this21.checkInput(e)},this.createButtonDisabled,function(e){return _this21.createMapproxyConfig()},this.createResult)}},{key:"renderLayer",value:function renderLayer(layer){var _this22=this;if(layer.Name){return html(_templateObject16_2b46c4105c5e11e9a640aba88724ddc3(),layer.Name,this.selectedLayers.has(layer.Name),function(e){return _this22.toggleCheck(layer.Name)},layer.Name,layer.Name,layer.Name,layer.Title?", ".concat(layer.Title):"")}if(layer.Title){return html(_templateObject17_2b46c4105c5e11e9a640aba88724ddc3(),layer.Title)}return html(_templateObject18_2b46c4105c5e11e9a640aba88724ddc3())}},{key:"renderLayers",value:function renderLayers(Layer,depth){var _this23=this;if(!Array.isArray(Layer)){Layer=[Layer]}if(!depth){depth=0}return Layer.map(function(layer){return html(_templateObject19_2b46c4105c5e11e9a640aba88724ddc3(),unsafeHTML("&nbsp;".repeat(depth)),_this23.renderLayer(layer),layer.Layer?_this23.renderLayers(layer.Layer,depth+1):"")})}},{key:"updateCreateButton",value:function updateCreateButton(){if(0===this.selectedLayers.size){this.createButtonDisabled=!0}else{var configname=this.shadowRoot.querySelector("#configname").value.trim().toLowerCase();this.createButtonDisabled=!(/^[a-z0-9][a-z0-9_-]*$/.test(configname)&&this.list.find(function(item){return item.name.toLowerCase().replace(/\.yaml$/,"")===configname})===void 0)}}},{key:"checkInput",value:function checkInput(e){this.updateCreateButton()}},{key:"toggleCheck",value:function toggleCheck(layername){if(this.selectedLayers.has(layername)){this.selectedLayers.delete(layername)}else{this.selectedLayers.add(layername)}this.updateCreateButton()}},{key:"toggleAllChecks",value:function toggleAllChecks(e){var _this24=this,checkboxes=Array.from(this.shadowRoot.querySelectorAll("input[type=\"checkbox\"]"));checkboxes.forEach(function(checkbox){if(checkbox.checked!==e.target.checked){checkbox.checked=e.target.checked;_this24.toggleCheck(checkbox.getAttribute("id"))}})}},{key:"selectAllLayers",value:function selectAllLayers(Layer,parent){var _this25=this;if(!Array.isArray(Layer)){Layer=[Layer]}Layer.forEach(function(layer){if(parent&&parent.SRS){var combinedSRS=new Set;parent.SRS.forEach(function(srs){return combinedSRS.add(srs)});if(layer.SRS){layer.SRS.forEach(function(srs){return combinedSRS.add(srs)})}layer.SRS=Array.from(combinedSRS)}if(layer.Name){_this25.selectedLayers.add(layer.Name)}if(layer.Layer){_this25.selectAllLayers(layer.Layer,layer)}})}},{key:"fetchCapabilities",value:function fetchCapabilities(e){var _this26=this;this.getcapabilitiesResult="Fetching...";setTimeout(function(){return _this26.getcapabilitiesResult=""},1e4);this.capabilities={};this.errorMessage="";this.selectedLayers=new Set;this.getcapabilitiesurl=this.shadowRoot.querySelector("input[name=\"wmscapabilitiesurl\"]").value.trim();if(""!==this.getcapabilitiesurl){var localConfig=JSON.parse(window.localStorage.config),fetchUrl="".concat(localConfig.adminserver,"getcapabilities?wmsurl=").concat(encodeURIComponent(this.getcapabilitiesurl));fetch(fetchUrl).then(function(response){if(!response.ok){_this26.getcapabilitiesResult=response.statusText;throw Error(response.statusText)}return response.json()}).then(function(json){if(!json.Capability){_this26.getcapabilitiesResult="Invalid capabilities";throw Error(JSON.stringify(json))}_this26.capabilities=json;_this26.selectAllLayers(_this26.capabilities.Capability.Layer);_this26.getcapabilitiesResult="Done"}).catch(function(error){_this26.getcapabilitiesResult=error;_this26.capabilities={};_this26.errorMessage=error})}}},{key:"getCapabilitiesLayer",value:function getCapabilitiesLayer(Layer,layername){var _this27=this,result=void 0;if(!Array.isArray(Layer)){Layer=[Layer]}// first look for sublayers
Layer.forEach(function(layer){if(!result){if(layer.Layer){result=_this27.getCapabilitiesLayer(layer.Layer,layername)}}});if(!result){Layer.forEach(function(layer){if(!result){if(layer.Name===layername){result=layer}}})}return result}},{key:"postMapproxyConfig",value:function postMapproxyConfig(adminserver,configname,config){var url=pathJoin([adminserver,"mapproxyupdate",configname+".yaml"]);return fetch(url,{method:"POST",mode:"cors",headers:{"Content-Type":"application/json"},redirect:"follow",referrer:"client",body:JSON.stringify(config)})}},{key:"createMapproxyConfig",value:function createMapproxyConfig(){var _this28=this;this.createResult="Creating...";var configname=this.shadowRoot.querySelector("#configname").value.trim().toLowerCase(),localConfig=JSON.parse(window.localStorage.config),selectedLayers=Array.from(this.selectedLayers).map(function(layername){return _this28.getCapabilitiesLayer(_this28.capabilities.Capability.Layer,layername)}),config={services:{demo:null,tms:null,wmts:null,wms:{srs:["EPSG:3857","EPSG:25831","EPSG:25832","EPSG:28992","EPSG:900913"],image_formats:["image/jpeg","image/png"],md:{title:this.capabilities.Service.Title,abstract:this.capabilities.Service.Abstract,online_resource:pathJoin([localConfig.metadata.online_resource,configname]),contact:{person:localConfig.metadata.contact.person,position:localConfig.metadata.contact.position,organization:localConfig.metadata.contact.organization,postcode:localConfig.metadata.contact.postcode,email:localConfig.metadata.contact.email,city:localConfig.metadata.contact.city,country:localConfig.metadata.contact.country},access_constraints:localConfig.metadata.access_constraints,fees:localConfig.metadata.fees}}},layers:selectedLayers.map(function(layer){var result={name:escape(layer.Name),title:layer.Title,sources:[escape(layer.Name)+"_cache"]};if(layer.Abstract&&""!==layer.Abstract){result.abstract=layer.Abstract}if(layer.ScaleHint&&layer.ScaleHint.min){result.max_res=layer.ScaleHint.min/1.4142}if(layer.ScaleHint&&layer.ScaleHint.max){result.min_res=layer.ScaleHint.max/1.4142}return result}),caches:selectedLayers.reduce(function(result,layer){result[escape(layer.Name)+"_cache"]={grids:["spherical_mercator"],sources:[escape(layer.Name)+"_wms"],format:"image/png",disable_storage:!1,cache:{type:"sqlite"}};return result},{}),sources:selectedLayers.reduce(function(result,layer){result[escape(layer.Name)+"_wms"]={type:"wms",wms_opts:{featureinfo:layer.queryable,legendgraphic:!0},supported_srs:[layerSRS(layer)],req:{url:_this28.capabilities.Capability.Request.GetMap.DCPType[0].HTTP.Get.OnlineResource,layers:layer.Name,transparent:!0}};if(layer.LatLonBoundingBox){if(-180>layer.LatLonBoundingBox[0]||180<layer.LatLonBoundingBox[0]||-180>layer.LatLonBoundingBox[2]||180<layer.LatLonBoundingBox[2]||-90>layer.LatLonBoundingBox[1]||90<layer.LatLonBoundingBox[1]||-90>layer.LatLonBoundingBox[3]||90<layer.LatLonBoundingBox[3]){// invalid latlonbbox
// temp: try 28992
result[escape(layer.Name)+"_wms"].coverage={bbox:layer.LatLonBoundingBox,bbox_srs:"EPSG:28992"}}else{result[escape(layer.Name)+"_wms"].coverage={bbox:layer.LatLonBoundingBox,bbox_srs:"EPSG:4326"}}}return result},{}),grids:{global_geodetic_sqrt2:{base:"GLOBAL_GEODETIC",res_factor:"sqrt2"},spherical_mercator:{base:"GLOBAL_MERCATOR",tile_size:[256,256],srs:"EPSG:3857"},nltilingschema:{tile_size:[256,256],srs:"EPSG:28992",bbox:[-285401.92,22598.08,595401.92,903401.92],bbox_srs:"EPSG:28992",min_res:3440.64,max_res:.21,origin:"sw"}},globals:{cache:{meta_buffer:200,meta_size:[4,4],base_dir:pathJoin([localConfig.mapproxydir,localConfig.mapproxy_cache,configname])},image:{resampling_method:"bicubic"/*this.postMapproxyConfig(localConfig.adminserver, configname, config)
              .then(()=>{
                  this.dispatchEvent(new CustomEvent('itemadd', {
                      detail: configname,
                      bubbles: true,
                      composed: true
                  }));
              })*/}}};this.postMapproxyConfig(localConfig.adminserver,configname,config).then(function(response){setTimeout(function(){return _this28.createResult=""},1e4);if(!response.ok){_this28.createResult=response.statusText}else{return response.json()}}).then(function(json){if(json.error){_this28.capabilities=json.error}else{_this28.createResult="Created!";_this28.dispatchEvent(new CustomEvent("itemadd",{detail:configname,bubbles:!0,composed:!0}))}})}}]);return MapproxyGetCaps}(LitElement);window.customElements.define("mapproxy-getcaps",MapproxyGetCaps);/* polyfill for String.repeat */if(!String.prototype.repeat){String.prototype.repeat=function(count){'use strict';if(null==this){throw new TypeError("can't convert "+this+" to object")}var str=""+this;// To convert string to integer.
count=+count;if(count!=count){count=0}if(0>count){throw new RangeError("repeat count must be non-negative")}if(count==1/0){throw new RangeError("repeat count must be less than infinity")}count=Math.floor(count);if(0==str.length||0==count){return""}// Ensuring count is a 31-bit integer allows us to heavily optimize the
// main part. But anyway, most current (August 2014) browsers can't handle
// strings 1 << 28 chars or longer, so:
if(str.length*count>=1<<28){throw new RangeError("repeat count must not overflow maximum string size")}var maxCount=str.length*count;count=Math.floor(Math.log(count)/Math.log(2));while(count){str+=str;count--}str+=str.substring(0,maxCount-str.length);return str}}var MapproxyLayer=/*#__PURE__*/function(_LitElement4){babelHelpers.inherits(MapproxyLayer,_LitElement4);babelHelpers.createClass(MapproxyLayer,null,[{key:"properties",get:function get(){return{itemname:{type:String},layer:{type:Object},localConfig:{type:Object},item:{type:Object},cacheResult:{type:String}}}},{key:"styles",get:function get(){return css(_templateObject20_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyLayer(){var _this29;babelHelpers.classCallCheck(this,MapproxyLayer);_this29=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyLayer).call(this));_this29.itemname="";_this29.layer={};_this29.item={};_this29.cacheResult="";return _this29}babelHelpers.createClass(MapproxyLayer,[{key:"render",value:function render(){var _this30=this;return html(_templateObject21_2b46c4105c5e11e9a640aba88724ddc3(),this.layer.name,this.localConfig.metadata.online_resource,this.itemname,this.layer.name,function(e){return _this30.clearCache(_this30.itemname,_this30.layer.name)},this.renderResolutions(),this.renderCoverage(),this.renderClearCacheResult())}},{key:"renderResolutions",value:function renderResolutions(){return html(_templateObject22_2b46c4105c5e11e9a640aba88724ddc3(),this.layer.min_res?html(_templateObject23_2b46c4105c5e11e9a640aba88724ddc3(),this.layer.min_res):"",this.layer.max_res?html(_templateObject24_2b46c4105c5e11e9a640aba88724ddc3(),this.layer.max_res):"")}},{key:"renderCoverage",value:function renderCoverage(){var cachename=this.layer.sources[0],sourcename=this.item.config.caches[cachename].sources[0],coverage=this.item.config.sources[sourcename].coverage;if(!coverage){return""}return html(_templateObject25_2b46c4105c5e11e9a640aba88724ddc3(),coverage.bbox.join(","),coverage.bbox_srs)}},{key:"renderClearCacheResult",value:function renderClearCacheResult(){return html(_templateObject26_2b46c4105c5e11e9a640aba88724ddc3(),this.cacheResult)}},{key:"resetCacheResult",value:function resetCacheResult(){var _this31=this;setTimeout(function(){return _this31.cacheResult=""},1e4)}},{key:"clearCache",value:function clearCache(itemname,layername){var _this32=this;this.cacheResult="clearing cache...";var cachename=this.layer.sources[0],url=pathJoin([this.localConfig.adminserver,"mapproxyclearcache",itemname+".yaml",cachename]);fetch(url).then(function(response){if(!response.ok){throw Error(response.statusText)}_this32.cacheResult="cache cleared";_this32.resetCacheResult();return response.json()}).then(function(json){if(json.error){if("object"===babelHelpers.typeof(json.error)){json.error=JSON.stringify(json.error)}_this32.cacheResult="cache clear, error: "+json.error;_this32.resetCacheResult();//throw Error(json.error);
}})}}]);return MapproxyLayer}(LitElement);window.customElements.define("mapproxy-layer",MapproxyLayer);var MapproxyItem=/*#__PURE__*/function(_LitElement5){babelHelpers.inherits(MapproxyItem,_LitElement5);babelHelpers.createClass(MapproxyItem,null,[{key:"properties",get:function get(){return{item:{type:Object},open:{type:Boolean},localConfig:{type:Object}}}},{key:"styles",get:function get(){return css(_templateObject27_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyItem(){var _this33;babelHelpers.classCallCheck(this,MapproxyItem);_this33=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyItem).call(this));_this33.item={};_this33.localConfig={};_this33.itemname="";return _this33}babelHelpers.createClass(MapproxyItem,[{key:"shouldUpdate",value:function shouldUpdate(changedProperties){if(changedProperties.has("item")){this.itemname=this.item.name.replace(/.yaml$/,"");this.open=!1}return!0}},{key:"render",value:function render(){var _this34=this;if(this.item.name){return html(_templateObject28_2b46c4105c5e11e9a640aba88724ddc3(),function(e){return _this34.toggleOpen(e)},this.open,this.item.name,this.renderItem())}return html(_templateObject29_2b46c4105c5e11e9a640aba88724ddc3())}},{key:"renderItem",value:function renderItem(){var _this35=this;if(!this.open){return html(_templateObject30_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject31_2b46c4105c5e11e9a640aba88724ddc3(),this.localConfig.metadata.online_resource,this.itemname,this.item.name,function(e){return _this35.deleteItem(e)},Object.keys(this.item.config.services).map(function(key){return html(_templateObject32_2b46c4105c5e11e9a640aba88724ddc3(),key)}),this.htmlTree(this.item.config.services.wms.md),this.item.config.layers.map(function(layer){return html(_templateObject33_2b46c4105c5e11e9a640aba88724ddc3(),_this35.itemname,_this35.item,layer,_this35.localConfig)}))}},{key:"toggleOpen",value:function toggleOpen(e){this.open=!this.open}},{key:"deleteItem",value:function deleteItem(e){if(confirm("permanently delete: "+this.item.name+" from server?")){this.dispatchEvent(new CustomEvent("itemdelete",{detail:this.item.name,bubbles:!0,composed:!0}))}}},{key:"htmlTree",value:function htmlTree(object){var result=[];for(var key in object){result.push(html(_templateObject34_2b46c4105c5e11e9a640aba88724ddc3(),key));var value=object[key];switch(babelHelpers.typeof(value)){case"string":case"number":case"undefined":case"boolean":result.push(html(_templateObject35_2b46c4105c5e11e9a640aba88724ddc3(),value));break;case"function":result.push(html(_templateObject36_2b46c4105c5e11e9a640aba88724ddc3()));break;case"object":if(null===value){result.push(html(_templateObject37_2b46c4105c5e11e9a640aba88724ddc3(),value))}else{result.push(html(_templateObject38_2b46c4105c5e11e9a640aba88724ddc3(),this.htmlTree(object[key])))}break;}}return result}}]);return MapproxyItem}(LitElement);window.customElements.define("mapproxy-item",MapproxyItem);var MapproxyList=/*#__PURE__*/function(_LitElement6){babelHelpers.inherits(MapproxyList,_LitElement6);babelHelpers.createClass(MapproxyList,null,[{key:"properties",get:function get(){return{config:{type:Object},list:{type:Array},error:{type:String},open:{type:Boolean},localConfig:{type:Object}}}},{key:"styles",get:function get(){return css(_templateObject39_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyList(){var _this36;babelHelpers.classCallCheck(this,MapproxyList);_this36=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyList).call(this));_this36.config={};_this36.localConfig={};_this36.list=[];return _this36}babelHelpers.createClass(MapproxyList,[{key:"render",value:function render(){var _this37=this;return html(_templateObject40_2b46c4105c5e11e9a640aba88724ddc3(),function(e){return _this37.toggleOpen(e)},this.renderList())}},{key:"renderList",value:function renderList(){var _this38=this;if(!this.open){return html(_templateObject41_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject42_2b46c4105c5e11e9a640aba88724ddc3(),this.list.map(function(item){return html(_templateObject43_2b46c4105c5e11e9a640aba88724ddc3(),item,_this38.localConfig)}))}},{key:"toggleOpen",value:function toggleOpen(e){this.open=!this.open}}]);return MapproxyList}(LitElement);_exports.MapproxyList=MapproxyList;window.customElements.define("mapproxy-list",MapproxyList);var mapproxyList={MapproxyList:MapproxyList};_exports.$mapproxyList=mapproxyList;var MapproxyNew=/*#__PURE__*/function(_LitElement7){babelHelpers.inherits(MapproxyNew,_LitElement7);babelHelpers.createClass(MapproxyNew,null,[{key:"properties",get:function get(){return{config:{type:Object},open:{type:Boolean},list:{type:Array}}}},{key:"styles",get:function get(){return css(_templateObject44_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyNew(){var _this39;babelHelpers.classCallCheck(this,MapproxyNew);_this39=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyNew).call(this));_this39.config={};_this39.open=!1;return _this39}babelHelpers.createClass(MapproxyNew,[{key:"render",value:function render(){var _this40=this;return html(_templateObject45_2b46c4105c5e11e9a640aba88724ddc3(),function(e){return _this40.toggleOpen(e)},this.mapproxyNewForm())}},{key:"mapproxyNewForm",value:function mapproxyNewForm(){if(!this.open){return html(_templateObject46_2b46c4105c5e11e9a640aba88724ddc3())}return html(_templateObject47_2b46c4105c5e11e9a640aba88724ddc3(),this.config,this.list)}},{key:"toggleOpen",value:function toggleOpen(e){this.open=!this.open}}]);return MapproxyNew}(LitElement);window.customElements.define("mapproxy-new",MapproxyNew);var MapproxyAdminApp=/*#__PURE__*/function(_LitElement8){babelHelpers.inherits(MapproxyAdminApp,_LitElement8);babelHelpers.createClass(MapproxyAdminApp,null,[{key:"properties",get:function get(){return{config:{type:Object},localConfig:{type:Object},list:{type:Array}}}},{key:"styles",get:function get(){return css(_templateObject48_2b46c4105c5e11e9a640aba88724ddc3())}}]);function MapproxyAdminApp(){var _this41;babelHelpers.classCallCheck(this,MapproxyAdminApp);_this41=babelHelpers.possibleConstructorReturn(this,babelHelpers.getPrototypeOf(MapproxyAdminApp).call(this));_this41.config={};_this41.error=void 0;_this41.list=[];fetch("./config.json").then(function(response){if(response.ok){return response.json()}else{return{error:response.statusText}}}).then(function(json){if(json.error){throw Error(json.error)}_this41.config=json;if(!window.localStorage.config){window.localStorage.config=JSON.stringify(json)}_this41.localConfig=JSON.parse(window.localStorage.config);_this41.fetchList(_this41.config.adminserver).then(function(json){return _this41.list=json}).catch(function(error){return _this41.error=JSON.stringify(error)})});return _this41}babelHelpers.createClass(MapproxyAdminApp,[{key:"render",value:function render(){var _this42=this;if(this.config.error){return html(_templateObject49_2b46c4105c5e11e9a640aba88724ddc3(),this.error)}if(this.list&&this.list.length&&this.list[0].error){this.error=JSON.stringify(this.list[0].error)}if(this.error){return html(_templateObject50_2b46c4105c5e11e9a640aba88724ddc3(),this.config.adminserver+"mapproxylist",this.error)}return html(_templateObject51_2b46c4105c5e11e9a640aba88724ddc3(),this.config,this.list,function(e){return _this42.localConfigUpdate(e)},function(e){return _this42.addItem(e)},this.config,this.list,this.localConfig,function(e){return _this42.deleteItem(e)})}},{key:"fetchList",value:function fetchList(adminserver){return fetch(adminserver+"mapproxylist").then(function(response){if(!response.ok){throw Error(response.statusText)}return response.json()})}},{key:"deleteItem",value:function deleteItem(e){var _this43=this,configName=e.detail,url=pathJoin([this.localConfig.adminserver,"mapproxydelete",configName]);fetch(url).then(function(response){if(!response.ok){throw Error(response.statusText)}return response.json()}).then(function(json){if(json.error){throw Error(json.error)}_this43.list=_this43.list.filter(function(item){return item.name!==configName})})}},{key:"addItem",value:function addItem(e){var _this44=this;this.fetchList(this.config.adminserver).then(function(json){return _this44.list=json}).catch(function(error){return _this44.error=JSON.stringify(error)})}},{key:"localConfigUpdate",value:function localConfigUpdate(){this.localConfig=JSON.parse(window.localStorage.config)}}]);return MapproxyAdminApp}(LitElement);window.customElements.define("mapproxyadmin-app",MapproxyAdminApp)});